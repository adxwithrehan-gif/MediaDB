/**
 * MediaDB - Worldwide Newsletter & Subscriber Tracking System
 * Handles country-wise audience detection, logging, and newsletter retention.
 */

(function () {
  const STORAGE_KEY = "mediadb_subscribers";

  function detectUserCountry() {
    try {
      const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
      if (timeZone.includes("America/New_York") || timeZone.includes("America/Los_Angeles") || timeZone.includes("America/Chicago")) return "United States";
      if (timeZone.includes("London") || timeZone.includes("Europe/London")) return "United Kingdom";
      if (timeZone.includes("Berlin") || timeZone.includes("Frankfurt")) return "Germany";
      if (timeZone.includes("Paris")) return "France";
      if (timeZone.includes("Tokyo")) return "Japan";
      if (timeZone.includes("Sydney") || timeZone.includes("Melbourne")) return "Australia";
      if (timeZone.includes("Toronto") || timeZone.includes("Vancouver")) return "Canada";
      if (timeZone.includes("Madrid")) return "Spain";
      if (timeZone.includes("Zurich")) return "Switzerland";
      if (timeZone.includes("Calcutta") || timeZone.includes("Kolkata") || timeZone.includes("Karachi")) return "South Asia";
      
      const lang = navigator.language || "en-US";
      if (lang.includes("-")) {
        const countryCode = lang.split("-")[1].toUpperCase();
        return countryCode;
      }
      return "Worldwide";
    } catch (e) {
      return "Worldwide";
    }
  }

  window.MediaDB_Subscriber = {
    detectCountry: detectUserCountry,

    getSubscribers: function () {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    },

    saveSubscriber: function (email, country) {
      if (!email || !email.includes("@")) {
        return { success: false, message: "Please enter a valid email address." };
      }

      const cleanCountry = country || detectUserCountry();
      const existing = this.getSubscribers();

      if (existing.some((s) => s.email.toLowerCase() === email.toLowerCase())) {
        return { success: true, alreadySubscribed: true, message: "You are already subscribed to MediaDB updates!" };
      }

      const newSub = {
        id: "sub_" + Date.now(),
        email: email.trim().toLowerCase(),
        country: cleanCountry,
        subscribedAt: new Date().toISOString(),
      };

      existing.unshift(newSub);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(existing));
      } catch (e) {}

      // Attempt async server sync if endpoint available
      try {
        fetch("/api/subscribe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newSub),
        }).catch(() => {});
      } catch (e) {}

      return {
        success: true,
        message: `Subscribed successfully from ${cleanCountry}! Welcome to MediaDB Worldwide alerts.`,
        subscriber: newSub,
      };
    },

    exportCSV: function () {
      const subs = this.getSubscribers();
      if (!subs.length) {
        alert("No subscribers collected yet.");
        return;
      }
      let csv = "ID,Email,Country,Date\n";
      subs.forEach((s) => {
        csv += `"${s.id}","${s.email}","${s.country}","${s.subscribedAt}"\n`;
      });
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `mediadb_subscribers_${new Date().toISOString().split("T")[0]}.csv`;
      a.click();
    }
  };
})();
