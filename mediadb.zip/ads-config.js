/**
 * MediaDB - Centralized Ad Management System
 * Configures Header, Footer, and In-Article responsive advertisement slots.
 * Supports Google AdSense, direct programmatic sponsors, and clean fallbacks.
 */

window.MediaDB_Ads = {
  enabled: true,
  debug: false,
  network: "MediaDB Premium Entertainment Network",

  slots: {
    header: {
      id: "ad-slot-header",
      enabled: true,
      format: "728x90 Leaderboard / 320x50 Mobile",
      placeholderText: "Official Streaming & Cinema Partners",
      sponsoredLabel: "Advertisement",
      render: function (containerEl) {
        if (!containerEl) return;
        containerEl.innerHTML = `
          <div class="w-full bg-gradient-to-r from-slate-50 via-teal-50/40 to-slate-50 border border-slate-200/80 rounded-xl p-3 text-center my-4 shadow-xs">
            <span class="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1">Sponsored Showcase</span>
            <div class="flex items-center justify-center gap-3 text-xs text-slate-700">
              <span class="inline-flex items-center gap-1 font-semibold text-teal-700 bg-white px-2 py-1 rounded shadow-xs border border-teal-100">
                ⭐ Ultra HD 4K Cinema Pass
              </span>
              <span class="hidden sm:inline text-slate-600">Stream newly released festival winners with lossless acoustics.</span>
              <a href="#explore" class="text-teal-600 hover:text-teal-700 font-semibold underline underline-offset-2">Claim Free Trial &rarr;</a>
            </div>
          </div>
        `;
      }
    },

    inArticle: {
      id: "ad-slot-in-article",
      enabled: true,
      format: "300x250 Medium Rectangle / Responsive In-Feed",
      render: function (containerEl) {
        if (!containerEl) return;
        containerEl.innerHTML = `
          <div class="my-6 p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
            <span class="text-[10px] uppercase font-semibold text-slate-400 block mb-2">MediaDB Verified Partner</span>
            <p class="text-sm font-medium text-slate-800 mb-2">Build & Host Web Apps for Lifetime Free with GitHub + AI Studio</p>
            <a href="https://ai.studio" target="_blank" rel="noopener noreferrer" class="inline-block text-xs font-semibold px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg transition-colors">
              Deploy Next App Free &rarr;
            </a>
          </div>
        `;
      }
    },

    footer: {
      id: "ad-slot-footer",
      enabled: true,
      format: "970x90 Large Leaderboard",
      render: function (containerEl) {
        if (!containerEl) return;
        containerEl.innerHTML = `
          <div class="w-full max-w-5xl mx-auto my-6 px-4 py-3 bg-white/80 border border-slate-200 rounded-xl text-center text-xs text-slate-500 shadow-xs">
            <span class="font-medium text-slate-700">MediaDB Worldwide Directory</span> — Connecting global audiences with real-time cinema metrics and trending entertainment intelligence.
          </div>
        `;
      }
    }
  },

  init: function () {
    if (this.debug) console.log("[MediaDB Ads] Engine initialized successfully.");
  }
};

if (typeof document !== "undefined") {
  document.addEventListener("DOMContentLoaded", function () {
    window.MediaDB_Ads.init();
  });
}
