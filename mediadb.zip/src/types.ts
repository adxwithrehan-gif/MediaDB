export interface CastMember {
  name: string;
  character?: string;
  profile_path?: string;
}

export interface Movie {
  id: number | string;
  title: string;
  poster_path: string;
  backdrop_path?: string;
  vote_average: number;
  vote_count?: number;
  release_date: string;
  overview: string;
  genre?: string[];
  genres?: string[];
  media_type?: 'movie' | 'web-series';
  badge?: string;
  tagline?: string;
  runtime?: string;
  director?: string;
  cast?: string[];
  cast_members?: CastMember[];
  budget?: string;
  revenue?: string;
  status?: string;
  original_language?: string;
  production_companies?: string[];
  imdb_id?: string;
}

export interface TVShow {
  id: number | string;
  name: string;
  poster_path: string;
  backdrop_path?: string;
  vote_average: number;
  vote_count?: number;
  first_air_date: string;
  last_air_date?: string;
  overview: string;
  seasons?: number;
  episodes?: number;
  status?: string;
  tagline?: string;
  network?: string;
  networks?: string[];
  badge?: string;
  genres?: string[];
  creator?: string;
  created_by?: string[];
  cast?: string[];
  cast_members?: CastMember[];
  original_language?: string;
  production_companies?: string[];
}

export interface PersonCredit {
  id: number | string;
  title: string;
  character?: string;
  year?: string;
  poster_path?: string;
  media_type?: string;
  vote_average?: number;
}

export interface Person {
  id: number | string;
  name: string;
  profile_path: string;
  popularity: number;
  rank?: number;
  known_for_department: string;
  biography?: string;
  birthday?: string;
  deathday?: string;
  place_of_birth?: string;
  notable_works: string[];
  credits?: PersonCredit[];
  imdb_id?: string;
}

export interface AwardNominee {
  title: string;
  person?: string;
  recipient?: string;
  details?: string;
  isWinner?: boolean;
}

export interface AwardCategory {
  id: string;
  ceremony: string;
  edition: string;
  year: string;
  category: string;
  status: string;
  winner: {
    title: string;
    person?: string;
    recipient?: string;
    description: string;
    image: string;
    tmdbId?: string | number;
  };
  nominees: AwardNominee[];
  organization: string;
  editionNumber: string;
}

export type AwardRecord = AwardCategory;

export interface NewsArticle {
  id: string;
  title: string;
  slug: string;
  summary: string;
  content: string;
  category: string;
  country: string;
  source?: string;
  searchVolume?: string;
  imageUrl: string;
  publishedAt: string;
  readTime: string;
  isHeadline?: boolean;
  author?: string;
  tags: string[];
  verified?: boolean;
}

export interface EarnMethod {
  id: string;
  title: string;
  category: string;
  skillLevel: 'Beginner' | 'Intermediate' | 'Advanced' | 'No Experience' | string;
  avgMonthlyEarning?: string;
  earningPotential?: string;
  payoutType?: string;
  regionAvailability?: string;
  timeCommitment?: string;
  timeToFirstDollar?: string;
  difficultyRating?: number;
  description: string;
  prerequisites: string[];
  stepByStepGuide: string[];
  recommendedPlatforms: { name: string; url: string; badge?: string }[];
  proTips?: string;
}

export interface Subscriber {
  id: string;
  email: string;
  country: string;
  subscribedAt: string;
  ipAddress?: string;
}

export interface SearchResultItem {
  id: string | number;
  type: 'movie' | 'tv' | 'person' | 'award' | 'news' | 'earn';
  title: string;
  subtitle: string;
  imageUrl?: string;
  badge?: string;
  link?: string;
}
