import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { AdBanner } from './components/AdBanner';
import { SearchModal } from './components/SearchModal';
import { DetailModal } from './components/DetailModal';
import { GeminiTrendGenerator } from './components/GeminiTrendGenerator';
import { MoviesView } from './components/MoviesView';
import { TvShowsView } from './components/TvShowsView';
import { PeopleView } from './components/PeopleView';
import { AwardsView } from './components/AwardsView';
import { NewsView } from './components/NewsView';
import { EarnOnlineView } from './components/EarnOnlineView';
import { ArticleView } from './components/ArticleView';
import { EarnDetailView } from './components/EarnDetailView';
import { Movie, TVShow, Person, AwardRecord, NewsArticle, EarnMethod } from './types';
import { initialMovies } from './data/mockData';

export default function App() {
  // Determine initial tab and ID from window.INITIAL_TAB, query param, or pathname
  const getInitialRoute = (): { tab: string; id: string } => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab');
      const idParam = params.get('id') || '';

      if (tabParam === 'article' || tabParam === 'news-detail') {
        return { tab: 'article', id: idParam };
      }
      if (tabParam === 'earn-detail' || tabParam === 'earn-blueprint') {
        return { tab: 'earn-detail', id: idParam };
      }
      if (tabParam) {
        return { tab: tabParam, id: idParam };
      }

      const pathname = window.location.pathname.toLowerCase();
      if (pathname.includes('/article/')) {
        const parts = pathname.split('/article/');
        return { tab: 'article', id: parts[1] || idParam };
      }
      if (pathname.includes('/earn/') && pathname !== '/earn' && pathname !== '/earn/') {
        const parts = pathname.split('/earn/');
        return { tab: 'earn-detail', id: parts[1] || idParam };
      }
      if (pathname.includes('movie')) return { tab: 'movies', id: '' };
      if (pathname.includes('tv')) return { tab: 'tv', id: '' };
      if (pathname.includes('people')) return { tab: 'people', id: '' };
      if (pathname.includes('award')) return { tab: 'awards', id: '' };
      if (pathname.includes('news')) return { tab: 'news', id: '' };
      if (pathname.includes('earn')) return { tab: 'earn-online', id: '' };
    }
    return { tab: 'movies', id: '' };
  };

  const initialRoute = getInitialRoute();
  const [activeTab, setActiveTab] = useState<string>(initialRoute.tab);
  const [currentId, setCurrentId] = useState<string>(initialRoute.id);
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [geminiModalOpen, setGeminiModalOpen] = useState<boolean>(false);
  const [selectedDetail, setSelectedDetail] = useState<{ item: any; type: string } | null>(null);

  // Sync tab with URL and document title
  const handleSelectTab = (tab: string, id: string = '') => {
    setActiveTab(tab);
    setCurrentId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Update browser URL query without reload
    if (typeof window !== 'undefined' && window.history) {
      const url = new URL(window.location.href);
      url.searchParams.set('tab', tab);
      if (id) {
        url.searchParams.set('id', id);
      } else {
        url.searchParams.delete('id');
      }
      window.history.pushState({}, '', url.toString());
    }

    const titles: Record<string, string> = {
      movies: 'Movies & Web Series — MediaDB Worldwide',
      tv: 'Television Shows & Broadcasts — MediaDB Worldwide',
      people: 'Popular People & Biographies — MediaDB Worldwide',
      awards: 'Rewards & Oscars — MediaDB Worldwide',
      news: 'Real-Time News Wire (Google Trends & Gemini) — MediaDB',
      'earn-online': 'Earn Online Money (1000+ Structured Posts) — MediaDB',
      article: 'Verified Article Wire — MediaDB',
      'earn-detail': 'Monetization Blueprint — MediaDB',
    };
    if (titles[tab]) {
      document.title = titles[tab];
    }
  };

  // Keyboard shortcut for universal search (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setSearchOpen(false);
        setSelectedDetail(null);
        setGeminiModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handle item selection: News & Earn open in a NEW TAB without modal popup!
  // Allowed categories for popup modal: 1. Movies 2. TV Shows 3. Popular People 4. Rewards & Oscars
  const handleOpenDetail = (item: any, type: string) => {
    if (type === 'news') {
      const targetId = item.slug || item.id;
      window.open(`/?tab=article&id=${encodeURIComponent(targetId)}`, '_blank');
      return;
    }

    if (type === 'earn' || type === 'earn-online') {
      const targetId = item.id;
      window.open(`/?tab=earn-detail&id=${encodeURIComponent(targetId)}`, '_blank');
      return;
    }

    // Modal is preserved strictly for: Movies, TV, People, Awards
    setSelectedDetail({ item, type });
  };

  const handleSelectTitle = (title: string) => {
    // Attempt finding movie or TV show or open generic detail
    const found = initialMovies.find((m) => m.title.toLowerCase() === title.toLowerCase());
    if (found) {
      setSelectedDetail({ item: found, type: 'movie' });
    } else {
      setSelectedDetail({
        item: {
          id: 'title-' + Date.now(),
          title,
          overview: `Official catalog listing for ${title} honored by the Academy.`,
          release_date: '2025-2026',
          vote_average: 84,
          director: 'International Production Crew',
        },
        type: 'movie',
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans selection:bg-teal-500 selection:text-white">
      {/* Sticky Top Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onOpenSearch={() => setSearchOpen(true)}
        onOpenAIGenerator={() => setGeminiModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
        {/* Header Ad Placement */}
        <AdBanner position="header" />

        {/* Dynamic Tab Views */}
        {activeTab === 'movies' && (
          <MoviesView onSelectMovie={(m: Movie) => handleOpenDetail(m, 'movie')} />
        )}

        {activeTab === 'tv' && (
          <TvShowsView onSelectShow={(s: TVShow) => handleOpenDetail(s, 'tv')} />
        )}

        {activeTab === 'people' && (
          <PeopleView onSelectPerson={(p: Person) => handleOpenDetail(p, 'people')} />
        )}

        {activeTab === 'awards' && (
          <AwardsView
            onSelectAward={(a: AwardRecord) => handleOpenDetail(a, 'awards')}
            onSelectTitle={handleSelectTitle}
          />
        )}

        {activeTab === 'news' && (
          <NewsView
            onSelectArticle={(art: NewsArticle) => handleOpenDetail(art, 'news')}
            onRequestGeminiSync={() => setGeminiModalOpen(true)}
          />
        )}

        {activeTab === 'earn-online' && (
          <EarnOnlineView
            onSelectMethod={(method: EarnMethod) => handleOpenDetail(method, 'earn-online')}
          />
        )}

        {activeTab === 'article' && (
          <ArticleView
            articleId={currentId}
            onBack={() => handleSelectTab('news')}
          />
        )}

        {activeTab === 'earn-detail' && (
          <EarnDetailView
            methodId={currentId}
            onBack={() => handleSelectTab('earn-online')}
          />
        )}

        {/* In-Article Mid-Page Ad Placement */}
        <AdBanner position="inArticle" />

        {/* Footer Ad Placement */}
        <AdBanner position="footer" />
      </main>

      {/* Global Sticky Footer with Worldwide Newsletter */}
      <Footer onSelectTab={handleSelectTab} />

      {/* Universal Real-Time Search Modal */}
      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectItem={(item, type) => handleOpenDetail(item, type)}
      />

      {/* Detail Modal with Clean Permalinks */}
      {selectedDetail && (
        <DetailModal
          item={selectedDetail.item}
          type={selectedDetail.type}
          onClose={() => setSelectedDetail(null)}
        />
      )}

      {/* Gemini AI Trend News Generator Modal */}
      <GeminiTrendGenerator
        isOpen={geminiModalOpen}
        onClose={() => setGeminiModalOpen(false)}
        onArticleGenerated={(article: NewsArticle) => {
          handleOpenDetail(article, 'news');
        }}
      />
    </div>
  );
}
