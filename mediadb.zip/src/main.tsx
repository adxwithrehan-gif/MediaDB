// Ensure window.fetch is writable and configurable in all sandbox / preview environments
(function fixFetchGetter() {
  try {
    if (typeof window !== 'undefined') {
      const origFetch = window.fetch;
      let curFetch = origFetch;
      Object.defineProperty(window, 'fetch', {
        get() {
          return curFetch || origFetch;
        },
        set(fn) {
          curFetch = fn;
        },
        configurable: true,
        enumerable: true,
      });
    }
  } catch {
    try {
      if (typeof Window !== 'undefined' && Window.prototype) {
        const protoFetch = Window.prototype.fetch;
        let cProtoFetch = protoFetch;
        Object.defineProperty(Window.prototype, 'fetch', {
          get() {
            return cProtoFetch || protoFetch;
          },
          set(fn) {
            cProtoFetch = fn;
          },
          configurable: true,
          enumerable: true,
        });
      }
    } catch {}
  }
})();

import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
