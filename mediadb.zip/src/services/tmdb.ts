import { Movie, TVShow, Person } from '../types';
import { initialMovies, initialTVShows, initialPeople } from '../data/mockData';

const TMDB_API_KEY = 'e0454b55527f15c2784604a0bc84df14';
const BASE_URL = 'https://api.themoviedb.org/3';
const IMAGE_BASE = 'https://image.tmdb.org/t/p/w500';
const BACKDROP_BASE = 'https://image.tmdb.org/t/p/original';

export async function fetchPopularMovies(page: number = 1): Promise<{ results: Movie[]; total_pages: number }> {
  try {
    const res = await fetch(`${BASE_URL}/movie/popular?api_key=${TMDB_API_KEY}&page=${page}`);
    if (!res.ok) throw new Error('Failed to fetch from TMDb');
    const data = await res.json();
    const formatted: Movie[] = data.results.map((item: any) => ({
      id: item.id,
      title: item.title || item.original_title,
      poster_path: item.poster_path ? `${IMAGE_BASE}${item.poster_path}` : initialMovies[0].poster_path,
      backdrop_path: item.backdrop_path ? `${BACKDROP_BASE}${item.backdrop_path}` : undefined,
      vote_average: Math.round((item.vote_average || 7.5) * 10),
      release_date: item.release_date || '2026',
      overview: item.overview || 'No synopsis available.',
      genre: ['Action', 'Cinema'],
      badge: 'Movie',
    }));
    return { results: formatted, total_pages: data.total_pages || 10 };
  } catch (err) {
    console.warn('TMDb live API fallback to curated dataset:', err);
    return { results: initialMovies, total_pages: 5 };
  }
}

export async function fetchMoviesByCategory(category: 'popular' | 'now_playing' | 'top_rated' | 'web_series', page: number = 1): Promise<Movie[]> {
  try {
    let endpoint = 'popular';
    if (category === 'now_playing') endpoint = 'now_playing';
    if (category === 'top_rated') endpoint = 'top_rated';
    if (category === 'web_series') {
      const tvRes = await fetch(`${BASE_URL}/trending/tv/week?api_key=${TMDB_API_KEY}&page=${page}`);
      if (!tvRes.ok) throw new Error('TMDb fail');
      const data = await tvRes.json();
      return data.results.map((item: any) => ({
        id: item.id,
        title: item.name || item.original_name,
        poster_path: item.poster_path ? `${IMAGE_BASE}${item.poster_path}` : initialMovies[0].poster_path,
        backdrop_path: item.backdrop_path ? `${BACKDROP_BASE}${item.backdrop_path}` : undefined,
        vote_average: Math.round((item.vote_average || 7.5) * 10),
        release_date: item.first_air_date || '2026',
        overview: item.overview || 'Web series streaming worldwide.',
        badge: 'Web Series',
      }));
    }

    const res = await fetch(`${BASE_URL}/movie/${endpoint}?api_key=${TMDB_API_KEY}&page=${page}`);
    if (!res.ok) throw new Error('TMDb fail');
    const data = await res.json();
    return data.results.map((item: any) => ({
      id: item.id,
      title: item.title || item.original_title,
      poster_path: item.poster_path ? `${IMAGE_BASE}${item.poster_path}` : initialMovies[0].poster_path,
      backdrop_path: item.backdrop_path ? `${BACKDROP_BASE}${item.backdrop_path}` : undefined,
      vote_average: Math.round((item.vote_average || 7.5) * 10),
      release_date: item.release_date || '2026',
      overview: item.overview || 'No synopsis available.',
      badge: 'Movie',
    }));
  } catch (err) {
    return initialMovies;
  }
}

export async function fetchTVShowsByCategory(category: 'popular' | 'top_rated' | 'on_the_air', page: number = 1): Promise<TVShow[]> {
  try {
    const res = await fetch(`${BASE_URL}/tv/${category}?api_key=${TMDB_API_KEY}&page=${page}`);
    if (!res.ok) throw new Error('Failed to fetch TV from TMDb');
    const data = await res.json();
    return data.results.map((item: any) => ({
      id: item.id,
      name: item.name || item.original_name,
      poster_path: item.poster_path ? `${IMAGE_BASE}${item.poster_path}` : initialTVShows[0].poster_path,
      backdrop_path: item.backdrop_path ? `${BACKDROP_BASE}${item.backdrop_path}` : undefined,
      vote_average: Math.round((item.vote_average || 7.5) * 10),
      first_air_date: item.first_air_date || '2025',
      overview: item.overview || 'Worldwide television broadcast.',
      badge: 'TV Series',
    }));
  } catch (err) {
    return initialTVShows;
  }
}

export async function fetchPopularPeople(page: number = 1): Promise<Person[]> {
  try {
    const res = await fetch(`${BASE_URL}/person/popular?api_key=${TMDB_API_KEY}&page=${page}`);
    if (!res.ok) throw new Error('Failed to fetch people from TMDb');
    const data = await res.json();
    return data.results.map((item: any, idx: number) => ({
      id: item.id,
      name: item.name,
      profile_path: item.profile_path ? `${IMAGE_BASE}${item.profile_path}` : initialPeople[0].profile_path,
      popularity: Math.round(item.popularity || 80),
      rank: (page - 1) * 20 + idx + 1,
      known_for_department: item.known_for_department || 'Acting',
      notable_works: (item.known_for || []).map((w: any) => w.title || w.name).filter(Boolean),
    }));
  } catch (err) {
    return initialPeople;
  }
}

export async function searchTMDb(query: string) {
  if (!query.trim()) return [];
  try {
    const res = await fetch(`${BASE_URL}/search/multi?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}`);
    if (!res.ok) throw new Error('Search failed');
    const data = await res.json();
    return (data.results || []).slice(0, 10).map((item: any) => ({
      id: item.id,
      type: item.media_type === 'tv' ? 'tv' : item.media_type === 'person' ? 'person' : 'movie',
      title: item.title || item.name,
      subtitle: item.release_date || item.first_air_date || item.known_for_department || 'TMDb Entity',
      imageUrl: item.poster_path || item.profile_path ? `${IMAGE_BASE}${item.poster_path || item.profile_path}` : undefined,
      badge: item.media_type ? item.media_type.toUpperCase() : 'ENTRY',
    }));
  } catch (err) {
    return [];
  }
}

// Fetch Full TMDb Details for Movie
export async function fetchMovieDetails(id: string | number): Promise<Partial<Movie> | null> {
  try {
    const res = await fetch(`${BASE_URL}/movie/${id}?api_key=${TMDB_API_KEY}&append_to_response=credits`);
    if (!res.ok) return null;
    const data = await res.json();

    const director = data.credits?.crew?.find((c: any) => c.job === 'Director')?.name;
    const castMembers = (data.credits?.cast || []).slice(0, 10).map((c: any) => ({
      name: c.name,
      character: c.character,
      profile_path: c.profile_path ? `${IMAGE_BASE}${c.profile_path}` : undefined,
    }));
    const castNames = castMembers.map((c: any) => c.name);
    const genres = (data.genres || []).map((g: any) => g.name);
    const production = (data.production_companies || []).map((p: any) => p.name);

    let runtimeStr = undefined;
    if (data.runtime) {
      const hrs = Math.floor(data.runtime / 60);
      const mins = data.runtime % 60;
      runtimeStr = `${hrs > 0 ? hrs + 'h ' : ''}${mins}m`;
    }

    return {
      id: data.id,
      title: data.title || data.original_title,
      tagline: data.tagline || undefined,
      overview: data.overview || 'No synopsis available on TMDb.',
      release_date: data.release_date || '2026',
      status: data.status,
      runtime: runtimeStr,
      vote_average: Math.round((data.vote_average || 7.5) * 10),
      vote_count: data.vote_count,
      genres,
      genre: genres,
      poster_path: data.poster_path ? `${IMAGE_BASE}${data.poster_path}` : undefined,
      backdrop_path: data.backdrop_path ? `${BACKDROP_BASE}${data.backdrop_path}` : undefined,
      director,
      cast: castNames,
      cast_members: castMembers,
      budget: data.budget > 0 ? `$${data.budget.toLocaleString()}` : undefined,
      revenue: data.revenue > 0 ? `$${data.revenue.toLocaleString()}` : undefined,
      original_language: data.original_language?.toUpperCase(),
      production_companies: production,
      imdb_id: data.imdb_id,
    };
  } catch (e) {
    console.warn('Error fetching live movie details from TMDb:', e);
    return null;
  }
}

// Fetch Full TMDb Details for TV Show
export async function fetchTVDetails(id: string | number): Promise<Partial<TVShow> | null> {
  try {
    const res = await fetch(`${BASE_URL}/tv/${id}?api_key=${TMDB_API_KEY}&append_to_response=credits`);
    if (!res.ok) return null;
    const data = await res.json();

    const createdBy = (data.created_by || []).map((c: any) => c.name);
    const castMembers = (data.credits?.cast || []).slice(0, 10).map((c: any) => ({
      name: c.name,
      character: c.character,
      profile_path: c.profile_path ? `${IMAGE_BASE}${c.profile_path}` : undefined,
    }));
    const castNames = castMembers.map((c: any) => c.name);
    const genres = (data.genres || []).map((g: any) => g.name);
    const networks = (data.networks || []).map((n: any) => n.name);
    const production = (data.production_companies || []).map((p: any) => p.name);

    return {
      id: data.id,
      name: data.name || data.original_name,
      tagline: data.tagline || undefined,
      overview: data.overview || 'No synopsis available on TMDb.',
      first_air_date: data.first_air_date || '2025',
      last_air_date: data.last_air_date,
      status: data.status,
      seasons: data.number_of_seasons,
      episodes: data.number_of_episodes,
      vote_average: Math.round((data.vote_average || 7.5) * 10),
      vote_count: data.vote_count,
      genres,
      networks,
      network: networks[0],
      poster_path: data.poster_path ? `${IMAGE_BASE}${data.poster_path}` : undefined,
      backdrop_path: data.backdrop_path ? `${BACKDROP_BASE}${data.backdrop_path}` : undefined,
      creator: createdBy[0],
      created_by: createdBy,
      cast: castNames,
      cast_members: castMembers,
      original_language: data.original_language?.toUpperCase(),
      production_companies: production,
    };
  } catch (e) {
    console.warn('Error fetching live TV details from TMDb:', e);
    return null;
  }
}

// Fetch Full TMDb Details for Person
export async function fetchPersonDetails(id: string | number): Promise<Partial<Person> | null> {
  try {
    const res = await fetch(`${BASE_URL}/person/${id}?api_key=${TMDB_API_KEY}&append_to_response=combined_credits`);
    if (!res.ok) return null;
    const data = await res.json();

    const rawCredits = (data.combined_credits?.cast || [])
      .filter((c: any) => c.title || c.name)
      .sort((a: any, b: any) => (b.popularity || 0) - (a.popularity || 0))
      .slice(0, 12)
      .map((c: any) => ({
        id: c.id,
        title: c.title || c.name,
        character: c.character,
        year: (c.release_date || c.first_air_date || '').slice(0, 4),
        poster_path: c.poster_path ? `${IMAGE_BASE}${c.poster_path}` : undefined,
        media_type: c.media_type,
        vote_average: Math.round((c.vote_average || 0) * 10),
      }));

    return {
      id: data.id,
      name: data.name,
      profile_path: data.profile_path ? `${IMAGE_BASE}${data.profile_path}` : undefined,
      popularity: Math.round(data.popularity || 80),
      known_for_department: data.known_for_department || 'Acting',
      biography: data.biography || 'Biography currently being compiled from TMDb records.',
      birthday: data.birthday,
      deathday: data.deathday,
      place_of_birth: data.place_of_birth,
      credits: rawCredits,
      notable_works: rawCredits.slice(0, 5).map((c: any) => c.title),
      imdb_id: data.imdb_id,
    };
  } catch (e) {
    console.warn('Error fetching live person details from TMDb:', e);
    return null;
  }
}
