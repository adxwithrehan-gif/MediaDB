import { useState, useEffect } from 'react';

/**
 * Hook to automatically hide top spotlight banners on slight scroll (threshold px)
 * and provide manual dismiss capability.
 */
export function useScrollHide(threshold = 25) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY || document.documentElement.scrollTop;
      if (scrollPos > threshold) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, [threshold]);

  const isVisible = !isScrolled && !isDismissed;

  return {
    isVisible,
    dismiss: () => setIsDismissed(true),
  };
}
