import React, { useState, useEffect } from 'react';
import { ArrowLeft, DollarSign, Clock, ShieldCheck, CheckCircle2, ExternalLink, Share2, Sparkles, AlertCircle, Award, Briefcase } from 'lucide-react';
import { EarnMethod } from '../types';
import { earnOnlineMethods } from '../data/mockData';

interface EarnDetailViewProps {
  methodId?: string;
  onBack: () => void;
}

export const EarnDetailView: React.FC<EarnDetailViewProps> = ({ methodId, onBack }) => {
  const method: EarnMethod =
    earnOnlineMethods.find((m) => m.id === methodId) || earnOnlineMethods[0];

  const [hoursPerWeek, setHoursPerWeek] = useState<number>(15);
  const [ratePerProject, setRatePerProject] = useState<number>(75);

  useEffect(() => {
    if (method?.title) {
      document.title = `${method.title} — Blueprint Guide`;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [method]);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      alert('Blueprint link copied to clipboard!');
    }
  };

  const calculatedMonthly = Math.round((hoursPerWeek / 5) * ratePerProject * 4);

  return (
    <article className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300 pb-16">
      {/* Top Bar Navigation */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors shadow-2xs cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to Earning Directory</span>
        </button>

        <button
          onClick={handleShare}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors shadow-2xs cursor-pointer"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Share Blueprint</span>
        </button>
      </div>

      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
        <span>Earn Online</span>
        <span>/</span>
        <span className="text-teal-700 font-semibold">{method.category}</span>
        <span>/</span>
        <span className="text-slate-500 truncate max-w-xs">{method.title}</span>
      </div>

      {/* Blueprint Header */}
      <header className="space-y-4 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="px-3 py-1 rounded-full font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 border border-emerald-200 text-[11px]">
            {method.category}
          </span>
          <span className="px-2.5 py-1 rounded-full font-semibold bg-slate-100 text-slate-700 text-[11px]">
            Skill Level: {method.skillLevel}
          </span>
          <span className="flex items-center gap-1 text-emerald-600 font-semibold text-xs ml-auto">
            <ShieldCheck className="w-4 h-4" /> 100% Verified Methodology
          </span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading tracking-tight leading-tight">
          {method.title}
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          {method.description}
        </p>

        {/* Highlighted Key Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-slate-100 text-xs">
          <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/80">
            <span className="text-slate-500 block mb-0.5 text-[10px] uppercase font-bold">
              Earning Potential
            </span>
            <span className="text-base sm:text-lg font-extrabold text-emerald-800">
              {method.earningPotential || method.avgMonthlyEarning}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-slate-500 block mb-0.5 text-[10px] uppercase font-bold">
              Time to First $
            </span>
            <span className="text-base sm:text-lg font-bold text-slate-800">
              {method.timeToFirstDollar || '14-30 Days'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-slate-500 block mb-0.5 text-[10px] uppercase font-bold">
              Time Commitment
            </span>
            <span className="text-base sm:text-lg font-bold text-slate-800">
              {method.timeCommitment || '10-20 hrs/wk'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-slate-500 block mb-0.5 text-[10px] uppercase font-bold">
              Difficulty Rating
            </span>
            <span className="text-base sm:text-lg font-bold text-teal-700">
              {method.difficultyRating ? `${method.difficultyRating}/10` : 'Moderate'}
            </span>
          </div>
        </div>
      </header>

      {/* Comprehensive Operational Overview (5+ Paragraphs Deep Dive) */}
      <section className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-xl font-bold text-slate-900 font-heading flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-teal-600" />
          <span>Operational Blueprint & Business Mechanics</span>
        </h2>

        <div className="space-y-4 text-sm sm:text-base text-slate-700 leading-relaxed">
          <p>
            The democratization of global digital work rails has elevated {method.title.toLowerCase()} into one of the most resilient, location-independent monetization vehicles in the modern digital economy. Unlike transient income hacks or speculative ventures, this operational model is anchored in providing tangible, verifiable value to commercial enterprises, content publishers, and high-growth startups seeking scalable execution.
          </p>
          <p>
            Historically, breaking into this sector required significant upfront capital and proprietary software suites. Today, modern cloud utilities and automated pipelines have compressed the barrier to entry by over 80%. Beginners who master fundamental quality controls and workflow discipline can achieve production velocity comparable to established agencies within four to six weeks of deliberate practice.
          </p>
          <p>
            Market demand across international hubs—particularly North America, Western Europe, and Southeast Asia—continues to outpace qualified practitioner supply. Clients frequently cite reliability, timely turnaround times, and professional communication as attributes they value equally with raw technical expertise. Positioning yourself as a communicative problem-solver immediately distinguishes your profile from automated competitors.
          </p>
          <p>
            Payout dynamics in this category typically operate on dual models: immediate milestone disbursements for defined deliverables, and compounding recurring retainer contracts once client trust is solidified. Reinvesting initial cashflows into portfolio polish, verified credential certifications, and workflow optimization accelerates monthly compound growth.
          </p>
          <p>
            To mitigate common freelancer friction points, this blueprint establishes concrete checkpoints designed to eliminate scope creep and ensure guaranteed payouts. By leveraging accredited escrow infrastructures and pre-vetted payout platforms, you safeguard your billable hours and maintain steady operational cashflow.
          </p>
        </div>
      </section>

      {/* Step-by-Step Implementation Roadmap */}
      <section className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-slate-900 font-heading flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-600" />
            <span>Step-by-Step Implementation Roadmap</span>
          </h2>
          <p className="text-xs text-slate-500">
            Execute these chronological phases in order to maximize payout velocity and avoid common pitfalls.
          </p>
        </div>

        <ol className="space-y-4">
          {method.stepByStepGuide.map((step, idx) => (
            <li
              key={idx}
              className="flex items-start gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200/80 hover:bg-teal-50/40 transition-colors"
            >
              <div className="w-8 h-8 rounded-xl bg-teal-600 text-white font-extrabold flex items-center justify-center shrink-0 text-sm shadow-xs">
                {idx + 1}
              </div>
              <div className="space-y-1 pt-0.5">
                <h3 className="font-bold text-slate-900 text-sm">
                  Phase {idx + 1} Execution
                </h3>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {step}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      {/* Verified Payout Platforms */}
      <section className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-xl font-bold text-slate-900 font-heading flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-emerald-600" />
          <span>Accredited Payout Platforms & Gateways</span>
        </h2>
        <p className="text-xs text-slate-500">
          Direct portals verified for secure escrow, transparent terms, and multi-currency bank disbursements.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {method.recommendedPlatforms.map((plat, idx) => (
            <a
              key={idx}
              href={plat.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 hover:bg-teal-50 border border-slate-200 hover:border-teal-300 transition-all group cursor-pointer"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-900 group-hover:text-teal-800">
                    {plat.name}
                  </span>
                  {plat.badge && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-teal-600 text-white rounded">
                      {plat.badge}
                    </span>
                  )}
                </div>
                <span className="text-xs text-slate-500 block">Direct official onboarding link</span>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-teal-600 group-hover:translate-x-0.5 transition-all" />
            </a>
          ))}
        </div>
      </section>

      {/* Prerequisites & Required Tools */}
      <section className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-xl font-bold text-slate-900 font-heading flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-teal-600" />
          <span>Essential Prerequisites & Infrastructure</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {method.prerequisites.map((req, idx) => (
            <div
              key={idx}
              className="flex items-start gap-2.5 p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span className="font-medium leading-relaxed">{req}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Pro Tips & Risk Mitigation */}
      <section className="p-6 sm:p-8 rounded-3xl bg-amber-50/60 border border-amber-200 space-y-3">
        <div className="flex items-center gap-2 text-amber-900 font-bold text-base">
          <AlertCircle className="w-5 h-5 text-amber-600" />
          <span>Field Guidance & Risk Advisory</span>
        </div>
        <p className="text-xs sm:text-sm text-amber-950/80 leading-relaxed">
          {method.proTips ||
            'Always secure a 30% to 50% upfront deposit or initiate contracts through accredited escrow platforms before commencing deliverable production. Keep clear written records of client scope requirements, and deliver initial milestones ahead of schedule to secure glowing five-star client testimonials.'}
        </p>
      </section>
    </article>
  );
};
