import React, { useState } from 'react';
import { Radio, Sparkles, Filter, Search, Clock, Globe2, ShieldCheck, ArrowRight, Loader2, RefreshCw, X } from 'lucide-react';
import { NewsArticle } from '../types';
import { initialNewsArticles, spotlightNewsArticle } from '../data/mockData';
import { useScrollHide } from '../hooks/useScrollHide';

interface NewsViewProps {
  onSelectArticle: (article: NewsArticle) => void;
  onRequestGeminiSync: () => void;
}

export const NewsView: React.FC<NewsViewProps> = ({ onSelectArticle, onRequestGeminiSync }) => {
  const [articles, setArticles] = useState<NewsArticle[]>(initialNewsArticles);
  const [selectedCountry, setSelectedCountry] = useState<string>('Worldwide');
  const [selectedCategory, setSelectedCategory] = useState<string>('All Categories');
  const [sortBy, setSortBy] = useState<'latest' | 'trending'>('latest');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const { isVisible: isSpotlightVisible, dismiss: dismissSpotlight } = useScrollHide(25);

  const countries = [
    'Worldwide',
    'United States',
    'United Kingdom',
    'Germany',
    'Japan',
    'France',
    'China',
    'Spain',
    'Australia',
    'Switzerland',
    'Canada',
  ];

  const categories = [
    'All Categories',
    'Entertainment',
    'Technology',
    'Sports',
    'Business and Finance',
    'Science',
    'Health',
  ];

  const handleRefreshFeed = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  const filteredArticles = articles.filter((art) => {
    if (selectedCountry !== 'Worldwide' && art.country !== selectedCountry) return false;
    if (selectedCategory !== 'All Categories' && art.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = art.title.toLowerCase().includes(q);
      const matchSummary = art.summary.toLowerCase().includes(q);
      const matchTags = art.tags.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchSummary && !matchTags) return false;
    }
    return true;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Section Header & Subtitle matching Screenshot 1 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
              Real-Time News Wire
            </h1>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Live global intelligence via Google Trend telegrams and 10+ international clusters.
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleRefreshFeed}
            disabled={isRefreshing}
            className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
            title="Refresh Feed"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-teal-600' : ''}`} />
            <span>Refresh Wire</span>
          </button>
        </div>
      </div>

      {/* Filter Bar directly below header matching Screenshot 1 */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Country Selector */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Country Cluster
            </label>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="w-full px-3 py-2 text-xs font-semibold rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              {countries.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Category Selector */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Subject Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 text-xs font-semibold rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Sort By */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Sort Sequence
            </label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3 py-2 text-xs font-semibold rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="latest">Latest First (Live)</option>
              <option value="trending">Trending Velocity (24h)</option>
            </select>
          </div>

          {/* Quick Search */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Headline Filter
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter current headlines..."
                className="w-full pl-8 pr-3 py-2 text-xs rounded-xl bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
          </div>
        </div>
      </div>

      {/* #1 Worldwide Trending Headline Banner (Compact Dark Bar, Auto-Hides on Scroll) */}
      {spotlightNewsArticle && (
        <div
          className={`transition-all duration-300 ease-in-out ${
            isSpotlightVisible
              ? 'max-h-36 opacity-100 translate-y-0 mb-4'
              : 'max-h-0 opacity-0 -translate-y-2 pointer-events-none mb-0 overflow-hidden'
          }`}
        >
          <section
            onClick={() => onSelectArticle(spotlightNewsArticle)}
            className="relative overflow-hidden rounded-2xl bg-slate-950 text-white shadow-md border border-slate-800 p-3 sm:p-4 cursor-pointer group hover:border-teal-500/50 transition-all"
          >
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3.5 min-w-0">
                <img
                  src={spotlightNewsArticle.imageUrl}
                  alt={spotlightNewsArticle.title}
                  className="w-14 h-14 sm:w-16 sm:h-16 object-cover rounded-xl shadow-md border border-slate-700 shrink-0 group-hover:scale-105 transition-transform"
                />
                <div className="min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-2 text-[11px]">
                    <span className="flex items-center gap-1 font-extrabold text-white bg-red-600 px-2 py-0.5 rounded-md text-[10px] uppercase tracking-wider shadow-xs">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                      {spotlightNewsArticle.searchVolume} Trends
                    </span>
                    <span className="text-teal-400 font-semibold hidden sm:inline">
                      {spotlightNewsArticle.category}
                    </span>
                    <span className="text-slate-400 hidden md:inline">• {spotlightNewsArticle.country}</span>
                    <span className="text-slate-400 hidden sm:inline">• {spotlightNewsArticle.publishedAt}</span>
                  </div>
                  <h2 className="text-sm sm:text-base font-bold text-white truncate font-heading group-hover:text-teal-400 transition-colors">
                    {spotlightNewsArticle.title}
                  </h2>
                  <p className="text-xs text-slate-300 line-clamp-1 max-w-2xl hidden md:block">
                    {spotlightNewsArticle.summary}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="inline-flex items-center gap-1 text-xs font-bold text-teal-400 px-3 py-1.5 rounded-lg bg-teal-950/70 border border-teal-500/30 group-hover:bg-teal-900 transition-colors">
                  <span>Read Article</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    dismissSpotlight();
                  }}
                  className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Dismiss banner"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </section>
        </div>
      )}

      {/* Latest High-Velocity Trends (17) 3-Column Cards Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-extrabold text-slate-900 font-heading">
            Latest High-Velocity Trends ({filteredArticles.length})
          </h3>
          <span className="text-xs text-slate-500">
            Updated automatically every 30 minutes
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.map((article) => (
            <div
              key={article.id}
              onClick={() => onSelectArticle(article)}
              className="card-3d bg-white rounded-2xl overflow-hidden border border-slate-200 cursor-pointer group flex flex-col justify-between"
            >
              {/* Card Image */}
              <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                <img
                  src={article.imageUrl}
                  alt={article.title}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-slate-950/80 backdrop-blur-xs text-white border border-slate-700">
                    {article.category}
                  </span>
                  {article.searchVolume && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-600 text-white">
                      {article.searchVolume}
                    </span>
                  )}
                </div>
                <div className="absolute bottom-2.5 left-2.5 bg-white/90 backdrop-blur-xs text-slate-800 text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs flex items-center gap-1">
                  <Globe2 className="w-3 h-3 text-teal-600" />
                  <span>{article.country}</span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-4 space-y-2.5 flex-1 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>{article.publishedAt}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {article.readTime}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-teal-700 transition-colors line-clamp-2 leading-snug">
                    {article.title}
                  </h4>

                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    {article.summary}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-[10px] text-slate-400">MediaDB Wire</span>
                  <span className="font-bold text-teal-600 group-hover:text-teal-700 flex items-center gap-1">
                    <span>Read Story</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
