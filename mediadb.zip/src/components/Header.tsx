import React, { useState } from 'react';
import { Film, Tv, Users, Award, Radio, DollarSign, Search, Menu, X, Sparkles } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenSearch: () => void;
  onOpenAIGenerator?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  onOpenSearch,
  onOpenAIGenerator,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'movies', label: 'Movies & Series', icon: Film },
    { id: 'tv', label: 'TV Shows', icon: Tv },
    { id: 'people', label: 'Popular People', icon: Users },
    { id: 'awards', label: 'Rewards & Oscars', icon: Award },
    { id: 'news', label: 'News (Real-Time)', icon: Radio, isLive: true },
    { id: 'earn-online', label: 'Earn Online', icon: DollarSign, isBadge: true },
  ];

  return (
    <header className="glass-nav sticky top-0 z-40 border-b border-slate-200/90 shadow-xs backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onSelectTab('movies')}
              className="flex items-center gap-2.5 text-left group cursor-pointer"
              id="header-brand-logo"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-600 to-emerald-400 flex items-center justify-center text-white font-bold text-xl shadow-md shadow-teal-600/20 group-hover:scale-105 transition-transform">
                M
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xl tracking-tight text-slate-900 font-heading">
                    Media<span className="text-teal-600">DB</span>
                  </span>
                </div>
                <span className="text-[10px] tracking-wider uppercase font-semibold text-slate-400 block -mt-1">
                  Worldwide Portal
                </span>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  id={`nav-link-${item.id}`}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 cursor-pointer ${
                    isActive
                      ? 'bg-teal-50 text-teal-700 shadow-xs border border-teal-200/60'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-teal-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.isLive && (
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                    </span>
                  )}
                  {item.isBadge && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold uppercase tracking-wider">
                      1000+
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action: Universal Live Search Button */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onOpenSearch}
              id="header-live-search-button"
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100/90 hover:bg-slate-200/80 text-slate-600 hover:text-slate-900 text-sm font-medium border border-slate-200 transition-all cursor-pointer shadow-2xs"
            >
              <Search className="w-4 h-4 text-slate-500" />
              <span className="hidden sm:inline">Search MediaDB...</span>
              <span className="sm:hidden">Search</span>
              <kbd className="hidden md:inline-block text-[11px] px-1.5 py-0.5 bg-white border border-slate-300 rounded text-slate-500 font-mono">
                Ctrl+K
              </kbd>
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 py-3 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                    isActive
                      ? 'bg-teal-50 text-teal-700'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 text-teal-600" />
                    <span>{item.label}</span>
                  </div>
                  {item.isLive && (
                    <span className="text-xs text-red-600 font-bold bg-red-50 px-2 py-0.5 rounded-full">
                      LIVE
                    </span>
                  )}
                  {item.isBadge && (
                    <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full">
                      1000+ Posts
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </header>
  );
};
