import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Search, X, Film, Tv, Users, Award, Newspaper, DollarSign, ArrowRight } from 'lucide-react';
import { initialMovies, initialTVShows, initialPeople, initialAwards, initialNewsArticles, earnOnlineMethods } from '../data/mockData';
import { searchTMDb } from '../services/tmdb';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectItem: (item: any, type: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onSelectItem }) => {
  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [liveTmdbResults, setLiveTmdbResults] = useState<any[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
      setLiveTmdbResults([]);
    }
  }, [isOpen]);

  // Live TMDb search debounced
  useEffect(() => {
    if (!query.trim() || query.length < 2) {
      setLiveTmdbResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      const results = await searchTMDb(query);
      setLiveTmdbResults(results);
    }, 280);
    return () => clearTimeout(timer);
  }, [query]);

  // Local dataset searching
  const localResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    const list: any[] = [];

    // Movies
    if (filterType === 'all' || filterType === 'movie') {
      initialMovies.forEach((m) => {
        if (m.title.toLowerCase().includes(q) || m.overview.toLowerCase().includes(q)) {
          list.push({ ...m, searchCategory: 'Movie', type: 'movie' });
        }
      });
    }

    // TV Shows
    if (filterType === 'all' || filterType === 'tv') {
      initialTVShows.forEach((t) => {
        if (t.name.toLowerCase().includes(q) || t.overview.toLowerCase().includes(q)) {
          list.push({ ...t, searchCategory: 'TV Show', type: 'tv' });
        }
      });
    }

    // People
    if (filterType === 'all' || filterType === 'people') {
      initialPeople.forEach((p) => {
        if (p.name.toLowerCase().includes(q) || p.notable_works.some(w => w.toLowerCase().includes(q))) {
          list.push({ ...p, searchCategory: 'Celebrity', type: 'people' });
        }
      });
    }

    // Awards
    if (filterType === 'all' || filterType === 'awards') {
      initialAwards.forEach((a) => {
        if (a.edition.toLowerCase().includes(q) || a.category.toLowerCase().includes(q) || a.winner.title.toLowerCase().includes(q)) {
          list.push({ ...a, searchCategory: 'Award', type: 'awards', title: `${a.edition} - ${a.category}` });
        }
      });
    }

    // News
    if (filterType === 'all' || filterType === 'news') {
      initialNewsArticles.forEach((n) => {
        if (n.title.toLowerCase().includes(q) || n.summary.toLowerCase().includes(q) || n.tags.some(t => t.toLowerCase().includes(q))) {
          list.push({ ...n, searchCategory: 'News', type: 'news' });
        }
      });
    }

    // Earn Online
    if (filterType === 'all' || filterType === 'earn') {
      earnOnlineMethods.forEach((e) => {
        if (e.title.toLowerCase().includes(q) || e.description.toLowerCase().includes(q) || e.category.toLowerCase().includes(q)) {
          list.push({ ...e, searchCategory: 'Earn Online', type: 'earn-online' });
        }
      });
    }

    return list.slice(0, 16);
  }, [query, filterType]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-950/40 backdrop-blur-xs transition-opacity">
      <div
        className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[80vh] animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3 bg-slate-50/70">
          <Search className="w-5 h-5 text-teal-600 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search Movies, TV Shows, People, Awards, Trends, and Guides..."
            className="w-full bg-transparent text-slate-900 placeholder-slate-400 text-base focus:outline-none font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 hover:bg-slate-200 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-semibold px-2 py-1 bg-slate-200 hover:bg-slate-300 rounded text-slate-600 cursor-pointer"
          >
            ESC
          </button>
        </div>

        {/* Filter categories tabs */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-slate-100 bg-white overflow-x-auto text-xs font-medium">
          {[
            { id: 'all', label: 'All Results' },
            { id: 'movie', label: 'Movies', icon: Film },
            { id: 'tv', label: 'TV Shows', icon: Tv },
            { id: 'people', label: 'People', icon: Users },
            { id: 'awards', label: 'Awards', icon: Award },
            { id: 'news', label: 'News Wire', icon: Newspaper },
            { id: 'earn', label: 'Earn Online', icon: DollarSign },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                filterType === tab.id
                  ? 'bg-teal-600 text-white font-semibold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-4 divide-y divide-slate-100">
          {!query.trim() ? (
            <div className="py-12 text-center text-slate-400">
              <Search className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              <p className="text-sm font-medium text-slate-600">Type a keyword to start searching</p>
              <p className="text-xs text-slate-400 mt-1">Search through millions of TMDb titles, awards, news, and guides.</p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {['Spider-Man', 'Reacher', 'Oscars 2025', 'Avatar: Fire and Ash', 'Prompt Engineering'].map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => setQuery(suggestion)}
                    className="text-xs px-2.5 py-1 bg-slate-100 hover:bg-teal-50 hover:text-teal-700 rounded-lg text-slate-600 transition-colors cursor-pointer border border-slate-200"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : localResults.length === 0 && liveTmdbResults.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              <p className="text-sm">No exact matches found for "{query}".</p>
              <p className="text-xs text-slate-400 mt-1">Try searching for generic terms like "Spider", "Drama", or "News".</p>
            </div>
          ) : (
            <div className="space-y-1">
              {/* Local curated results */}
              {localResults.map((item, idx) => (
                <div
                  key={`res-${idx}-${item.id}`}
                  onClick={() => {
                    onSelectItem(item, item.type);
                    onClose();
                  }}
                  className="flex items-center justify-between p-3 rounded-xl hover:bg-teal-50/60 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    {item.poster_path || item.profile_path || item.imageUrl ? (
                      <img
                        src={item.poster_path || item.profile_path || item.imageUrl}
                        alt=""
                        className="w-11 h-14 object-cover rounded-md shadow-xs shrink-0"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-11 h-14 bg-teal-100 text-teal-700 rounded-md flex items-center justify-center font-bold text-xs shrink-0">
                        {item.searchCategory?.[0] || 'M'}
                      </div>
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900 group-hover:text-teal-700">
                          {item.title || item.name}
                        </span>
                        <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                          {item.searchCategory}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 line-clamp-1 mt-0.5 max-w-md">
                        {item.overview || item.summary || item.description || (item.notable_works && item.notable_works.join(', ')) || 'Detailed record in MediaDB catalog.'}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600 group-hover:translate-x-0.5 transition-all" />
                </div>
              ))}

              {/* Live TMDb hits if available */}
              {liveTmdbResults.length > 0 && (
                <div className="pt-3">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-teal-700 block mb-2 px-2">
                    Live TMDb API Matches
                  </span>
                  {liveTmdbResults.map((item, idx) => (
                    <div
                      key={`tmdb-${idx}-${item.id}`}
                      onClick={() => {
                        onSelectItem(item, item.type);
                        onClose();
                      }}
                      className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center gap-3">
                        {item.imageUrl && (
                          <img
                            src={item.imageUrl}
                            alt=""
                            className="w-10 h-13 object-cover rounded shadow-xs shrink-0"
                            loading="lazy"
                          />
                        )}
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-slate-800 group-hover:text-teal-600">
                              {item.title}
                            </span>
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200 font-semibold">
                              {item.badge}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400">{item.subtitle}</p>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500">
          <span>Search MediaDB Universal Index • Instant single-click navigation</span>
        </div>
      </div>
    </div>
  );
};
