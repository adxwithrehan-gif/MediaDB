import React, { useState, useEffect } from 'react';
import { Users, Star, ArrowRight, Loader2, Sparkles, Award, X } from 'lucide-react';
import { Person } from '../types';
import { initialPeople, spotlightPerson } from '../data/mockData';
import { fetchPopularPeople } from '../services/tmdb';
import { useScrollHide } from '../hooks/useScrollHide';

interface PeopleViewProps {
  onSelectPerson: (person: Person) => void;
}

export const PeopleView: React.FC<PeopleViewProps> = ({ onSelectPerson }) => {
  const [people, setPeople] = useState<Person[]>(initialPeople);
  const [loading, setLoading] = useState<boolean>(false);
  const [page, setPage] = useState<number>(1);
  const { isVisible: isSpotlightVisible, dismiss: dismissSpotlight } = useScrollHide(25);

  useEffect(() => {
    let isMounted = true;
    async function loadPeople() {
      setLoading(true);
      try {
        const results = await fetchPopularPeople(1);
        if (isMounted && results && results.length > 0) {
          setPeople(results);
          setPage(1);
        }
      } catch (e) {
        console.warn('Fallback to initial people dataset:', e);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadPeople();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleLoadMore = async () => {
    const nextPage = page + 1;
    setLoading(true);
    try {
      const results = await fetchPopularPeople(nextPage);
      if (results && results.length > 0) {
        setPeople((prev) => [...prev, ...results]);
        setPage(nextPage);
      }
    } catch (e) {
      console.warn('Cannot load more people:', e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Featured Celebrity Spotlight Card (Compact & Auto-Hides on Scroll) */}
      <div
        className={`transition-all duration-300 ease-in-out ${
          isSpotlightVisible
            ? 'max-h-48 opacity-100 translate-y-0 mb-4'
            : 'max-h-0 opacity-0 -translate-y-2 pointer-events-none mb-0 overflow-hidden'
        }`}
      >
        <section className="relative overflow-hidden rounded-2xl bg-slate-950 text-white shadow-md border border-slate-800">
          <div className="absolute inset-0 z-0 opacity-25">
            <img
              src={spotlightPerson.profile_path}
              alt={spotlightPerson.name}
              className="w-full h-full object-cover object-top filter blur-xs"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/95 to-slate-950/80" />
          </div>

          <div className="relative z-10 p-3 sm:p-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <img
                src={spotlightPerson.profile_path}
                alt={spotlightPerson.name}
                className="w-12 h-16 sm:w-14 sm:h-18 object-cover rounded-xl shadow-md border border-slate-700 shrink-0"
              />
              <div className="min-w-0 space-y-1">
                <div className="flex flex-wrap items-center gap-2 text-[11px]">
                  <span className="flex items-center gap-1 font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded-md border border-amber-500/30">
                    <Sparkles className="w-3 h-3" /> #1 Trending
                  </span>
                  <span className="text-teal-400 font-medium">
                    {spotlightPerson.known_for_department}
                  </span>
                </div>
                <h2 className="text-sm sm:text-base font-bold text-white truncate font-heading">
                  {spotlightPerson.name}
                </h2>
                <p className="text-xs text-slate-300 line-clamp-1 max-w-2xl hidden md:block">
                  {spotlightPerson.biography}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onSelectPerson(spotlightPerson)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs transition-all shadow-md shadow-teal-600/20 cursor-pointer"
              >
                <Award className="w-3 h-3" />
                <span className="hidden sm:inline">Biography</span>
              </button>
              <button
                onClick={dismissSpotlight}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      </div>

      {/* Section Header & Subtitle */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-2">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-6 h-6 text-teal-600" />
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
              Popular People & Biographies
            </h2>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Globally recognized actors, directors, writers, and industry visionaries.
          </p>
        </div>
      </div>

      {/* 6-Column Grid of People Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 sm:gap-5">
        {people.map((person) => (
          <div
            key={person.id}
            onClick={() => onSelectPerson(person)}
            className="card-3d group overflow-hidden cursor-pointer flex flex-col justify-between"
          >
            <div className="relative aspect-2/3 overflow-hidden bg-slate-100">
              <img
                src={person.profile_path}
                alt={person.name}
                loading="lazy"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />

              {/* Popularity Rank Badge */}
              <div className="absolute top-2 right-2 flex items-center gap-1 bg-slate-950/80 backdrop-blur-xs text-white text-[11px] font-bold px-2 py-0.5 rounded-full shadow-md border border-slate-700">
                <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                <span>★ {person.popularity}</span>
              </div>

              <div className="absolute bottom-2 left-2 bg-teal-700/90 text-white text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded shadow-xs">
                {person.known_for_department}
              </div>
            </div>

            <div className="p-3">
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-teal-600 transition-colors">
                {person.name}
              </h3>
              <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                {person.notable_works.join(', ')}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Load More Button */}
      <div className="pt-4 text-center">
        <button
          onClick={handleLoadMore}
          disabled={loading}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-sm font-bold border border-slate-200 shadow-xs hover:border-slate-300 transition-all cursor-pointer disabled:opacity-50"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
              <span>Synchronizing Celebrities...</span>
            </>
          ) : (
            <>
              <span>Load Next Page of Celebrities</span>
              <ArrowRight className="w-4 h-4 text-teal-600" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
