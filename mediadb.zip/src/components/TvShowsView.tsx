import React, { useState, useEffect } from 'react';
import { Star, Tv, ArrowRight, Loader2, Play, Sparkles, X } from 'lucide-react';
import { TVShow } from '../types';
import { initialTVShows, spotlightTVShow } from '../data/mockData';
import { fetchTVShowsByCategory } from '../services/tmdb';
import { useScrollHide } from '../hooks/useScrollHide';

interface TvShowsViewProps {
  onSelectShow: (show: TVShow) => void;
}

export const TvShowsView: React.FC<TvShowsViewProps> = ({ onSelectShow }) => {
  const [activeCategory, setActiveCategory] = useState<'popular' | 'top_rated' | 'on_the_air'>('popular');
  const [shows, setShows] = useState<TVShow[]>(initialTVShows);
  const [loading, setLoading] = useState<boolean>(false);
  const [page, setPage] = useState<number>(1);
  const { isVisible: isSpotlightVisible, dismiss: dismissSpotlight } = useScrollHide(25);

  useEffect(() => {
    let isMounted = true;
    async function loadShows() {
      setLoading(true);
      try {
        const results = await fetchTVShowsByCategory(activeCategory, 1);
        if (isMounted && results && results.length > 0) {
          setShows(results);
          setPage(1);
        }
      } catch (e) {
        console.warn('Fallback to initial TV shows:', e);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadShows();
    return () => {
      isMounted = false;
    };
  }, [activeCategory]);

  const handleLoadMore = async () => {
    const nextPage = page + 1;
    setLoading(true);
    try {
      const results = await fetchTVShowsByCategory(activeCategory, nextPage);
      if (results && results.length > 0) {
        setShows((prev) => [...prev, ...results]);
        setPage(nextPage);
      }
    } catch (e) {
      console.warn('Error loading more TV shows:', e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Featured TV Show Hero Banner (Compact & Auto-Hides on Scroll) */}
      <div
        className={`transition-all duration-300 ease-in-out ${
          isSpotlightVisible
            ? 'max-h-48 opacity-100 translate-y-0 mb-4'
            : 'max-h-0 opacity-0 -translate-y-2 pointer-events-none mb-0 overflow-hidden'
        }`}
      >
        <section className="relative overflow-hidden rounded-2xl bg-slate-950 text-white shadow-md border border-slate-800">
          <div className="absolute inset-0 z-0 opacity-30">
            <img
              src={spotlightTVShow.backdrop_path || spotlightTVShow.poster_path}
              alt={spotlightTVShow.name}
              className="w-full h-full object-cover object-center filter blur-xs"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/95 to-slate-950/80" />
          </div>

          <div className="relative z-10 p-3 sm:p-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <img
                src={spotlightTVShow.poster_path}
                alt={spotlightTVShow.name}
                className="w-12 h-16 sm:w-14 sm:h-20 object-cover rounded-xl shadow-md border border-slate-700 shrink-0"
              />
              <div className="min-w-0 space-y-1">
                <div className="flex flex-wrap items-center gap-2 text-[11px]">
                  <span className="flex items-center gap-1 font-bold text-teal-400 bg-teal-950/80 px-2 py-0.5 rounded-md border border-teal-500/30">
                    <Sparkles className="w-3 h-3" /> TV Spotlight
                  </span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <Star className="w-3 h-3 fill-emerald-400" /> {spotlightTVShow.vote_average}%
                  </span>
                  <span className="text-slate-400 hidden sm:inline">• {spotlightTVShow.network || 'Prime Video'}</span>
                </div>
                <h2 className="text-sm sm:text-base font-bold text-white truncate font-heading">
                  {spotlightTVShow.name}
                </h2>
                <p className="text-xs text-slate-300 line-clamp-1 max-w-2xl hidden md:block">
                  {spotlightTVShow.overview}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onSelectShow(spotlightTVShow)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs transition-all shadow-md shadow-teal-600/20 cursor-pointer"
              >
                <Play className="w-3 h-3 fill-white" />
                <span className="hidden sm:inline">Episodes</span>
              </button>
              <button
                onClick={dismissSpotlight}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      </div>

      {/* Section Header & Subtitle */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-2">
        <div>
          <div className="flex items-center gap-2">
            <Tv className="w-6 h-6 text-teal-600" />
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
              Television Shows & Broadcasts
            </h2>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Global Series, Original Streaming Networks & Live Broadcasts.
          </p>
        </div>

        {/* Filter tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100/90 rounded-xl border border-slate-200/80 overflow-x-auto text-xs font-semibold">
          {[
            { id: 'popular', label: 'Popular Series' },
            { id: 'top_rated', label: 'Top Rated' },
            { id: 'on_the_air', label: 'Currently On Air' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id as any)}
              className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === tab.id
                  ? 'bg-white text-teal-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 6-Column Grid of TV Shows */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 sm:gap-5">
        {shows.map((show) => (
          <div
            key={show.id}
            onClick={() => onSelectShow(show)}
            className="card-3d group overflow-hidden cursor-pointer flex flex-col justify-between"
          >
            <div className="relative aspect-2/3 overflow-hidden bg-slate-100">
              <img
                src={show.poster_path}
                alt={show.name}
                loading="lazy"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute top-2 right-2 flex items-center gap-1 bg-slate-950/80 backdrop-blur-xs text-white text-[11px] font-bold px-2 py-0.5 rounded-full shadow-md border border-slate-700">
                <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                <span>{show.vote_average}%</span>
              </div>

              {show.network && (
                <div className="absolute bottom-2 left-2 bg-slate-900/90 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs">
                  {show.network}
                </div>
              )}
            </div>

            <div className="p-3">
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-teal-600 transition-colors">
                {show.name}
              </h3>
              <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                <span>{show.first_air_date?.slice(0, 4) || 'Series'}</span>
                <span className="group-hover:translate-x-0.5 transition-transform text-teal-600 font-semibold">
                  Episodes &rarr;
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Load More Button */}
      <div className="pt-4 text-center">
        <button
          onClick={handleLoadMore}
          disabled={loading}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-sm font-bold border border-slate-200 shadow-xs hover:border-slate-300 transition-all cursor-pointer disabled:opacity-50"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
              <span>Synchronizing TV Series...</span>
            </>
          ) : (
            <>
              <span>Load Next Page of TV Shows</span>
              <ArrowRight className="w-4 h-4 text-teal-600" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
