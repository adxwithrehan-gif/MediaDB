import React, { useState, useEffect } from 'react';
import { X, Star, Calendar, Clock, Film, Award, DollarSign, Share2, Users, Tv, UserCheck, Globe } from 'lucide-react';
import { fetchMovieDetails, fetchTVDetails, fetchPersonDetails } from '../services/tmdb';

interface DetailModalProps {
  item: any;
  type: string;
  onClose: () => void;
}

export const DetailModal: React.FC<DetailModalProps> = ({ item: initialItem, type, onClose }) => {
  const [details, setDetails] = useState<any>(initialItem);
  const [loadingTMDb, setLoadingTMDb] = useState<boolean>(false);

  useEffect(() => {
    setDetails(initialItem);
    let isMounted = true;

    async function loadFullTMDb() {
      if (!initialItem?.id) return;
      setLoadingTMDb(true);
      try {
        if (type === 'movie') {
          const liveData = await fetchMovieDetails(initialItem.id);
          if (liveData && isMounted) {
            setDetails((prev: any) => ({ ...prev, ...liveData }));
          }
        } else if (type === 'tv') {
          const liveData = await fetchTVDetails(initialItem.id);
          if (liveData && isMounted) {
            setDetails((prev: any) => ({ ...prev, ...liveData }));
          }
        } else if (type === 'people' || type === 'person') {
          const liveData = await fetchPersonDetails(initialItem.id);
          if (liveData && isMounted) {
            setDetails((prev: any) => ({ ...prev, ...liveData }));
          }
        }
      } catch (err) {
        console.warn('Could not load extra TMDb details:', err);
      } finally {
        if (isMounted) setLoadingTMDb(false);
      }
    }

    loadFullTMDb();
    return () => {
      isMounted = false;
    };
  }, [initialItem, type]);

  if (!details) return null;

  const permalink = type === 'movie'
    ? `/movie/${details.id}`
    : type === 'tv'
    ? `/tv/${details.id}`
    : type === 'people' || type === 'person'
    ? `/person/${details.id}`
    : `/awards/${details.id}`;

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`${window.location.origin}${permalink}`);
      alert(`Permalink copied to clipboard: ${window.location.origin}${permalink}`);
    }
  };

  const imageSrc = details.poster_path || details.profile_path || details.imageUrl || details.winner?.image;
  const genresList = details.genres || details.genre || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs">
      <div
        className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-100/70 px-2.5 py-1 rounded-full">
              {type === 'people' ? 'PERSON' : type.toUpperCase()}
            </span>
            <span className="text-xs text-slate-400 font-mono hidden sm:inline">
              {permalink}
            </span>
            {loadingTMDb && (
              <span className="text-[11px] text-teal-600 font-medium animate-pulse hidden md:inline">
                Loading TMDb details...
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
              title="Copy link"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          <div className="flex flex-col sm:flex-row gap-6">
            {/* Thumbnail / Poster */}
            {imageSrc && (
              <img
                src={imageSrc}
                alt={details.title || details.name}
                className="w-full sm:w-52 h-72 object-cover rounded-xl shadow-md border border-slate-200 shrink-0"
              />
            )}

            {/* Core Info */}
            <div className="flex-1 space-y-3">
              <h2 className="text-2xl font-bold text-slate-900 font-heading">
                {details.title || details.name}
              </h2>

              {/* Badges / Rating */}
              <div className="flex flex-wrap items-center gap-2.5 text-xs">
                {details.vote_average !== undefined && (
                  <span className="flex items-center gap-1 font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    <Star className="w-3.5 h-3.5 fill-emerald-500 text-emerald-500" />
                    {details.vote_average}% User Score
                    {details.vote_count ? ` (${details.vote_count} votes)` : ''}
                  </span>
                )}
                {details.release_date && (
                  <span className="flex items-center gap-1 text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full font-medium">
                    <Calendar className="w-3.5 h-3.5" /> {details.release_date}
                  </span>
                )}
                {details.first_air_date && (
                  <span className="flex items-center gap-1 text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full font-medium">
                    <Calendar className="w-3.5 h-3.5" /> Premiered {details.first_air_date}
                  </span>
                )}
                {details.runtime && (
                  <span className="flex items-center gap-1 text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full font-medium">
                    <Clock className="w-3.5 h-3.5" /> {details.runtime}
                  </span>
                )}
                {details.seasons && (
                  <span className="flex items-center gap-1 text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full font-medium">
                    <Tv className="w-3.5 h-3.5" /> {details.seasons} {details.seasons > 1 ? 'Seasons' : 'Season'} {details.episodes ? `• ${details.episodes} Ep` : ''}
                  </span>
                )}
                {details.status && (
                  <span className="text-slate-700 bg-slate-100 font-semibold px-2.5 py-1 rounded-full">
                    Status: {details.status}
                  </span>
                )}
                {details.network && (
                  <span className="text-slate-700 bg-slate-100 font-semibold px-2.5 py-1 rounded-full">
                    {details.network}
                  </span>
                )}
                {details.known_for_department && (
                  <span className="text-teal-700 bg-teal-50 font-semibold px-2.5 py-1 rounded-full border border-teal-200">
                    Primary: {details.known_for_department}
                  </span>
                )}
                {details.original_language && (
                  <span className="text-slate-600 bg-slate-100 font-medium px-2 py-0.5 rounded text-[11px]">
                    Lang: {details.original_language}
                  </span>
                )}
              </div>

              {/* Genre Pills */}
              {genresList.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {genresList.map((g: string, i: number) => (
                    <span key={i} className="text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200/80">
                      {g}
                    </span>
                  ))}
                </div>
              )}

              {/* Tagline */}
              {details.tagline && (
                <p className="italic text-xs text-slate-500 border-l-2 border-teal-500 pl-3 py-1">
                  "{details.tagline}"
                </p>
              )}

              {/* Overview / Biography */}
              <p className="text-sm text-slate-700 leading-relaxed pt-1">
                {details.overview || details.biography || details.summary || details.description || details.winner?.description}
              </p>
            </div>
          </div>

          {/* Additional details for Movie / TV */}
          {(details.director || details.creator || details.budget || details.revenue || details.production_companies?.length > 0) && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
              {details.director && (
                <div>
                  <span className="text-slate-400 block mb-0.5 uppercase font-bold">Director</span>
                  <span className="font-semibold text-slate-800">{details.director}</span>
                </div>
              )}
              {details.creator && (
                <div>
                  <span className="text-slate-400 block mb-0.5 uppercase font-bold">Creator</span>
                  <span className="font-semibold text-slate-800">{details.creator}</span>
                </div>
              )}
              {details.budget && (
                <div>
                  <span className="text-slate-400 block mb-0.5 uppercase font-bold">Budget</span>
                  <span className="font-semibold text-slate-800">{details.budget}</span>
                </div>
              )}
              {details.revenue && (
                <div>
                  <span className="text-slate-400 block mb-0.5 uppercase font-bold">Box Office</span>
                  <span className="font-semibold text-slate-800">{details.revenue}</span>
                </div>
              )}
              {details.production_companies && details.production_companies.length > 0 && (
                <div className="col-span-2">
                  <span className="text-slate-400 block mb-0.5 uppercase font-bold">Studio & Production</span>
                  <span className="font-semibold text-slate-800">{details.production_companies.slice(0, 3).join(', ')}</span>
                </div>
              )}
            </div>
          )}

          {/* Cast members with photos / characters if available */}
          {details.cast_members && details.cast_members.length > 0 && (
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-teal-600" />
                Featured Cast & Characters (TMDb)
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {details.cast_members.slice(0, 8).map((actor: any, idx: number) => (
                  <div key={idx} className="flex items-center gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                    {actor.profile_path ? (
                      <img
                        src={actor.profile_path}
                        alt={actor.name}
                        className="w-10 h-10 rounded-full object-cover shrink-0 border border-slate-300"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold shrink-0 text-xs">
                        {actor.name.charAt(0)}
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-900 truncate">{actor.name}</p>
                      {actor.character && (
                        <p className="text-[11px] text-slate-500 truncate">{actor.character}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Fallback basic cast tags if cast_members not loaded yet */}
          {(!details.cast_members || details.cast_members.length === 0) && details.cast && details.cast.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Key Cast</h4>
              <div className="flex flex-wrap gap-1.5">
                {details.cast.map((actor: string, i: number) => (
                  <span key={i} className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded text-slate-700 font-medium text-xs">
                    {actor}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Person Filmography / Notable Works */}
          {(details.credits && details.credits.length > 0) && (
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Film className="w-3.5 h-3.5 text-teal-600" />
                Notable Filmography & Credits (TMDb)
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {details.credits.slice(0, 8).map((credit: any, idx: number) => (
                  <div key={idx} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs space-y-1">
                    {credit.poster_path && (
                      <img
                        src={credit.poster_path}
                        alt={credit.title}
                        className="w-full h-28 object-cover rounded mb-1"
                      />
                    )}
                    <p className="font-bold text-slate-900 truncate">{credit.title}</p>
                    {credit.character && (
                      <p className="text-[11px] text-slate-500 truncate">as {credit.character}</p>
                    )}
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span>{credit.year || 'Film'}</span>
                      {credit.vote_average > 0 && (
                        <span className="text-emerald-700 font-bold">{credit.vote_average}%</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Fallback person notable works */}
          {(!details.credits || details.credits.length === 0) && details.notable_works && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Notable Works</h4>
              <div className="flex flex-wrap gap-1.5">
                {details.notable_works.map((work: string, i: number) => (
                  <span key={i} className="px-2.5 py-1 bg-teal-50 border border-teal-200 text-teal-800 rounded font-semibold text-xs">
                    {work}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Award Nominees List */}
          {details.nominees && details.nominees.length > 0 && (
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-amber-500" />
                Official Category Nominees
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {details.nominees.map((nom: any, idx: number) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border text-xs flex items-center justify-between ${
                      nom.isWinner
                        ? 'bg-amber-50/80 border-amber-300 text-amber-950 font-bold'
                        : 'bg-slate-50 border-slate-200 text-slate-800'
                    }`}
                  >
                    <div>
                      <p className="font-bold">{nom.title}</p>
                      {nom.person && <p className="text-slate-500 text-[11px]">{nom.person}</p>}
                      {nom.details && <p className="text-slate-400 text-[10px]">{nom.details}</p>}
                    </div>
                    {nom.isWinner && (
                      <span className="px-2 py-0.5 bg-amber-500 text-white rounded text-[10px] uppercase font-bold shrink-0">
                        Winner
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end text-xs">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
