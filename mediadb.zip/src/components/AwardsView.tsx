import React, { useState } from 'react';
import { Award, Trophy, ArrowRight, ExternalLink, Sparkles, CheckCircle, X } from 'lucide-react';
import { AwardRecord } from '../types';
import { initialAwards } from '../data/mockData';
import { useScrollHide } from '../hooks/useScrollHide';

interface AwardsViewProps {
  onSelectAward: (award: AwardRecord) => void;
  onSelectTitle: (title: string) => void;
}

export const AwardsView: React.FC<AwardsViewProps> = ({ onSelectAward, onSelectTitle }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const { isVisible: isBannerVisible, dismiss: dismissBanner } = useScrollHide(25);

  const filterTabs = [
    { id: 'all', label: 'All Prestigious Awards' },
    { id: 'oscars', label: 'Academy Awards (Oscars) 🏆' },
    { id: 'emmys', label: 'Primetime Emmy Awards 📺' },
    { id: 'globes', label: 'Golden Globe Awards 🌟' },
    { id: 'bafta', label: 'BAFTA Film Awards 🎭' },
    { id: 'cannes', label: 'Cannes Film Festival 🎬' },
  ];

  const filteredAwards = initialAwards.filter((award) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'oscars') return award.organization.toLowerCase().includes('academy');
    if (activeCategory === 'emmys') return award.organization.toLowerCase().includes('television') || award.edition.toLowerCase().includes('emmy');
    if (activeCategory === 'globes') return award.edition.toLowerCase().includes('globe');
    if (activeCategory === 'bafta') return award.edition.toLowerCase().includes('bafta');
    if (activeCategory === 'cannes') return award.edition.toLowerCase().includes('cannes');
    return true;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Banner Card (Compact & Auto-Hides on Scroll) */}
      <div
        className={`transition-all duration-300 ease-in-out ${
          isBannerVisible
            ? 'max-h-36 opacity-100 translate-y-0 mb-4'
            : 'max-h-0 opacity-0 -translate-y-2 pointer-events-none mb-0 overflow-hidden'
        }`}
      >
        <section className="relative overflow-hidden rounded-2xl bg-slate-950 text-white shadow-md border border-slate-800 p-3 sm:p-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                <Trophy className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-[11px]">
                  <span className="font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/30">
                    Hall of Fame
                  </span>
                  <span className="text-slate-400 hidden sm:inline">Oscars • Emmys • Golden Globes • BAFTA</span>
                </div>
                <h1 className="text-sm sm:text-base font-extrabold text-white truncate font-heading mt-0.5">
                  Entertainment Awards & Honors
                </h1>
                <p className="text-xs text-slate-400 truncate hidden md:block">
                  Celebrating historic & 2026 academy achievements in cinema, television & streaming.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="hidden lg:inline-flex px-2.5 py-1 rounded-md bg-teal-950/80 border border-teal-500/30 text-teal-300 text-xs items-center gap-1">
                <Sparkles className="w-3 h-3" /> Latest Galas
              </span>
              <button
                onClick={dismissBanner}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      </div>

      {/* Filter Tabs matching Screenshot 2 */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-heading">
              Official Award Ceremonies
            </h2>
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredAwards.length} Honored Categories
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeCategory === tab.id
                  ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 2-Column Grid of Award Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredAwards.map((award) => (
          <div
            key={award.id}
            className="card-3d bg-white p-6 rounded-2xl flex flex-col justify-between space-y-5"
          >
            {/* Award Header */}
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[11px] font-extrabold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                  {award.edition} • {award.year}
                </span>
                <span className="text-xs font-semibold text-slate-400">
                  {award.organization}
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 font-heading">
                {award.category}
              </h3>
            </div>

            {/* Winner Spotlight Card */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-amber-50/70 via-orange-50/40 to-amber-50/70 border border-amber-200/90 flex flex-col sm:flex-row gap-4">
              <img
                src={award.winner.image}
                alt={award.winner.title}
                className="w-full sm:w-28 h-36 object-cover rounded-lg shadow-sm border border-amber-300 shrink-0"
              />
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-800">
                  <Trophy className="w-3.5 h-3.5 text-amber-600" />
                  <span>WINNER (HONORED)</span>
                </div>
                <h4 className="text-base font-bold text-slate-900">
                  {award.winner.title}
                </h4>
                <p className="text-xs font-medium text-slate-600">
                  {award.winner.recipient || award.winner.person}
                </p>
                <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                  {award.winner.description}
                </p>
                <button
                  onClick={() => onSelectAward(award)}
                  className="inline-flex items-center gap-1 text-xs font-bold text-amber-700 hover:text-amber-800 pt-1 cursor-pointer"
                >
                  <span>View Official Award Record</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Other Nominees List */}
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block font-heading">
                Other Nominees in this Category
              </span>
              <div className="space-y-2">
                {award.nominees.map((nom, idx) => (
                  <div
                    key={idx}
                    onClick={() => onSelectTitle(nom.title)}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors text-xs cursor-pointer group"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-slate-300 group-hover:bg-amber-500 transition-colors" />
                      <span className="font-semibold text-slate-800 group-hover:text-amber-700">
                        {nom.title}
                      </span>
                      <span className="text-slate-400 text-[11px] hidden sm:inline">
                        — {nom.recipient || nom.person || nom.details}
                      </span>
                    </div>
                    <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-amber-600 shrink-0" />
                  </div>
                ))}
              </div>
            </div>

            {/* Card Footer */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>AMPAS & International Academy Certified</span>
              <button
                onClick={() => onSelectAward(award)}
                className="text-teal-600 hover:text-teal-700 font-semibold cursor-pointer"
              >
                Full Ceremony Data &rarr;
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
