import React, { useEffect } from 'react';
import { ArrowLeft, Clock, Globe2, Share2, ShieldCheck, Tag, TrendingUp, Sparkles, User, Calendar, ExternalLink } from 'lucide-react';
import { NewsArticle } from '../types';
import { initialNewsArticles, spotlightNewsArticle } from '../data/mockData';

interface ArticleViewProps {
  articleId?: string;
  onBack: () => void;
  onSelectArticle?: (article: NewsArticle) => void;
}

export const ArticleView: React.FC<ArticleViewProps> = ({ articleId, onBack, onSelectArticle }) => {
  // Locate article by slug or id
  const article: NewsArticle =
    initialNewsArticles.find((a) => a.id === articleId || a.slug === articleId) ||
    (spotlightNewsArticle.id === articleId || spotlightNewsArticle.slug === articleId
      ? spotlightNewsArticle
      : initialNewsArticles[0]);

  useEffect(() => {
    if (article?.title) {
      document.title = `${article.title} — MediaDB Wire`;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [article]);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      alert('Article link copied to clipboard!');
    }
  };

  // Split content into paragraphs
  const paragraphs = (article.content || '')
    .split('\n\n')
    .map((p) => p.trim())
    .filter(Boolean);

  // Suggested related articles
  const relatedArticles = initialNewsArticles
    .filter((a) => a.id !== article.id && (a.category === article.category || a.country === article.country))
    .slice(0, 3);

  return (
    <article className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300 pb-16">
      {/* Top Bar with Back Navigation & Action Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors shadow-2xs cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to News Wire</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors shadow-2xs cursor-pointer"
            title="Share article"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Share</span>
          </button>
        </div>
      </div>

      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
        <span>News Wire</span>
        <span>/</span>
        <span className="text-teal-700 font-semibold">{article.category}</span>
        <span>/</span>
        <span className="text-slate-500 truncate max-w-xs">{article.title}</span>
      </div>

      {/* Header Section */}
      <header className="space-y-4">
        {/* Badges Bar */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="px-3 py-1 rounded-full font-bold uppercase tracking-wider text-teal-800 bg-teal-100/80 border border-teal-200 text-[11px]">
            {article.category}
          </span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 font-semibold text-[11px]">
            <Globe2 className="w-3.5 h-3.5 text-teal-600" />
            {article.country}
          </span>
          {article.searchVolume && (
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 font-bold text-[11px]">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              {article.searchVolume} Google Search Volume
            </span>
          )}
          <span className="flex items-center gap-1 text-emerald-600 font-semibold text-xs ml-auto">
            <ShieldCheck className="w-4 h-4" /> Verified Journalism
          </span>
        </div>

        {/* Article Headline */}
        <h1 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 font-heading tracking-tight leading-tight">
          {article.title}
        </h1>

        {/* Summary Lead */}
        <p className="text-base sm:text-lg text-slate-600 leading-relaxed font-normal border-l-4 border-teal-500 pl-4 py-1">
          {article.summary}
        </p>

        {/* Metadata Row (Author, Date, Read Time) */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-b border-slate-200 py-3 text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-xs">
                {(article.author || 'M').charAt(0)}
              </div>
              <span className="font-semibold text-slate-800">
                {article.author || 'Senior Cinema & Tech Correspondent'}
              </span>
            </div>
            <span className="hidden sm:inline text-slate-300">•</span>
            <div className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>{article.publishedAt}</span>
            </div>
          </div>

          <div className="flex items-center gap-1 text-slate-500 font-medium">
            <Clock className="w-3.5 h-3.5" />
            <span>{article.readTime}</span>
          </div>
        </div>
      </header>

      {/* Featured High-Res Imagery */}
      {article.imageUrl && (
        <div className="space-y-2">
          <div className="relative aspect-16/9 rounded-2xl overflow-hidden shadow-lg border border-slate-200 bg-slate-100">
            <img
              src={article.imageUrl}
              alt={article.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-3 left-3 bg-slate-950/80 backdrop-blur-xs text-white text-[11px] font-medium px-3 py-1 rounded-lg border border-slate-800 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-400" />
              <span>Verified Global Wire Intelligence • Syndicated Feed</span>
            </div>
          </div>
          <p className="text-[11px] text-slate-400 italic text-center">
            {article.title} — Photography via MediaDB Global Intelligence Bureau.
          </p>
        </div>
      )}

      {/* Key Takeaways Box */}
      <div className="p-5 rounded-2xl bg-teal-50/60 border border-teal-200/80 space-y-2.5">
        <div className="flex items-center gap-2 text-teal-900 font-bold text-sm">
          <Sparkles className="w-4 h-4 text-teal-600" />
          <span>Executive Summary & Key Developments</span>
        </div>
        <ul className="space-y-1.5 text-xs sm:text-sm text-teal-950/80 list-disc list-inside leading-relaxed">
          <li>Full international confirmation registered across primary industry tracking bureaus.</li>
          <li>Over {article.searchVolume || '50,000+'} real-time search queries recorded across search telemetry.</li>
          <li>Strategic implications impacting international market distribution and streaming release windows.</li>
        </ul>
      </div>

      {/* Main Article Body (5 to 8 Detailed Paragraphs) */}
      <div className="prose prose-slate max-w-none space-y-5 text-slate-800 text-sm sm:text-base leading-relaxed">
        {paragraphs.map((para, idx) => (
          <p
            key={idx}
            className={`text-slate-800 leading-relaxed ${
              idx === 0
                ? 'first-letter:text-4xl first-letter:font-extrabold first-letter:text-teal-700 first-letter:mr-2 first-letter:float-left'
                : ''
            }`}
          >
            {para}
          </p>
        ))}
      </div>

      {/* Tags Section */}
      {article.tags && article.tags.length > 0 && (
        <div className="pt-6 border-t border-slate-200 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider">
            <Tag className="w-3.5 h-3.5" />
            <span>Associated Topic Clusters</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {article.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 rounded-lg bg-slate-100 border border-slate-200 text-slate-700 font-medium text-xs hover:bg-teal-50 hover:text-teal-800 transition-colors"
              >
                #{tag}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Related Stories Section */}
      {relatedArticles.length > 0 && (
        <div className="pt-8 border-t border-slate-200 space-y-4">
          <h3 className="text-xl font-bold text-slate-900 font-heading">
            More From {article.category} Wire
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {relatedArticles.map((rel) => (
              <div
                key={rel.id}
                onClick={() => {
                  if (onSelectArticle) {
                    onSelectArticle(rel);
                  } else {
                    window.open(`/?tab=article&id=${encodeURIComponent(rel.slug || rel.id)}`, '_blank');
                  }
                }}
                className="p-3 bg-white rounded-xl border border-slate-200 hover:border-teal-300 hover:shadow-md transition-all cursor-pointer group space-y-2"
              >
                <div className="aspect-16/10 rounded-lg overflow-hidden bg-slate-100">
                  <img
                    src={rel.imageUrl}
                    alt={rel.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>{rel.country}</span>
                  <span>{rel.readTime}</span>
                </div>
                <h4 className="text-xs font-bold text-slate-900 group-hover:text-teal-700 line-clamp-2 leading-snug">
                  {rel.title}
                </h4>
              </div>
            ))}
          </div>
        </div>
      )}
    </article>
  );
};
