import React, { useEffect, useRef } from 'react';

interface AdBannerProps {
  position: 'header' | 'inArticle' | 'footer';
}

export const AdBanner: React.FC<AdBannerProps> = ({ position }) => {
  const adRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).MediaDB_Ads && adRef.current) {
      const slot = (window as any).MediaDB_Ads.slots[position];
      if (slot && slot.enabled && slot.render) {
        slot.render(adRef.current);
      }
    }
  }, [position]);

  // Ads logic preserved in GitHub files, but suppressed from public view as requested
  return null;

  /* eslint-disable no-unreachable */
  return (
    <div className="w-full my-3" id={`ad-container-${position}`}>
      <div ref={adRef}>
        {/* Fallback while ads-config initializes */}
        {position === 'header' && (
          <div className="w-full bg-gradient-to-r from-slate-50 via-teal-50/40 to-slate-50 border border-slate-200/80 rounded-xl p-3 text-center shadow-xs">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
              Sponsored Showcase
            </span>
            <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-slate-700">
              <span className="inline-flex items-center gap-1 font-semibold text-teal-700 bg-white px-2 py-0.5 rounded shadow-xs border border-teal-100">
                ⭐ Ultra HD 4K Cinema Pass
              </span>
              <span className="hidden sm:inline text-slate-600">
                Stream newly released festival winners with lossless acoustics.
              </span>
              <a href="#explore" className="text-teal-600 hover:text-teal-700 font-semibold underline underline-offset-2">
                Claim Free Trial &rarr;
              </a>
            </div>
          </div>
        )}

        {position === 'inArticle' && (
          <div className="my-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
            <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
              MediaDB Verified Partner
            </span>
            <p className="text-xs font-semibold text-slate-800 mb-2">
              Build & Host Web Apps for Lifetime Free with GitHub Pages + Google AI Studio
            </p>
            <a
              href="https://ai.studio"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block text-xs font-semibold px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg transition-colors"
            >
              Deploy Next App Free &rarr;
            </a>
          </div>
        )}

        {position === 'footer' && (
          <div className="w-full max-w-5xl mx-auto my-4 px-4 py-2.5 bg-white/80 border border-slate-200 rounded-xl text-center text-xs text-slate-500 shadow-xs">
            <span className="font-semibold text-slate-700">MediaDB Worldwide Directory</span> — Connecting global audiences with real-time cinema metrics and trending entertainment intelligence.
          </div>
        )}
      </div>
    </div>
  );
};
