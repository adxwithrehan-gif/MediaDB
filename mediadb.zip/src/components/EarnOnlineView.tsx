import React, { useState } from 'react';
import { DollarSign, Briefcase, Zap, Calculator, CheckCircle2, ArrowRight, ExternalLink, ShieldCheck, Sparkles, X } from 'lucide-react';
import { EarnMethod } from '../types';
import { earnOnlineMethods } from '../data/mockData';
import { useScrollHide } from '../hooks/useScrollHide';

interface EarnOnlineViewProps {
  onSelectMethod: (method: EarnMethod) => void;
}

export const EarnOnlineView: React.FC<EarnOnlineViewProps> = ({ onSelectMethod }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedSkill, setSelectedSkill] = useState<string>('All');
  const [calcHours, setCalcHours] = useState<number>(15);
  const [calcTier, setCalcTier] = useState<string>('Intermediate');
  const { isVisible: isBannerVisible, dismiss: dismissBanner } = useScrollHide(25);

  const categories = [
    'All',
    'AI & Automation',
    'Freelancing',
    'Content Creation',
    'Affiliate Marketing',
    'Digital Products',
    'Remote Work',
  ];

  const filteredMethods = earnOnlineMethods.filter((item) => {
    if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
    if (selectedSkill !== 'All' && item.skillLevel !== selectedSkill) return false;
    return true;
  });

  // Calculate projected monthly income
  const hourlyRate = calcTier === 'Beginner' ? 22 : calcTier === 'Intermediate' ? 45 : 85;
  const projectedMonthly = calcHours * hourlyRate * 4;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Hero Banner (Compact & Auto-Hides on Scroll) */}
      <div
        className={`transition-all duration-300 ease-in-out ${
          isBannerVisible
            ? 'max-h-36 opacity-100 translate-y-0 mb-4'
            : 'max-h-0 opacity-0 -translate-y-2 pointer-events-none mb-0 overflow-hidden'
        }`}
      >
        <section className="relative overflow-hidden rounded-2xl bg-slate-950 text-white shadow-md border border-slate-800 p-3 sm:p-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                <DollarSign className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-[11px]">
                  <span className="font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                    1,248 Guides
                  </span>
                  <span className="text-slate-400 hidden sm:inline">Zero MLM • Verified Cashout Platforms</span>
                </div>
                <h1 className="text-sm sm:text-base font-extrabold text-white truncate font-heading mt-0.5">
                  Earn Online Money Directory
                </h1>
                <p className="text-xs text-slate-400 truncate hidden md:block">
                  Legitimate, verifiable online monetization roadmaps & payout calculators for 2026.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="hidden lg:inline-flex px-2.5 py-1 rounded-md bg-teal-950/80 border border-teal-500/30 text-teal-300 text-xs items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Legit
              </span>
              <button
                onClick={dismissBanner}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      </div>

      {/* Interactive Earning Potential Calculator */}
      <div className="card-3d bg-white p-6 rounded-2xl border border-slate-200">
        <div className="flex items-center gap-2 mb-4">
          <Calculator className="w-5 h-5 text-teal-600" />
          <h2 className="text-lg font-extrabold text-slate-900 font-heading">
            Interactive Earning Potential Estimator
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
              Weekly Hours Committed: <span className="text-teal-700 font-extrabold">{calcHours} hrs/week</span>
            </label>
            <input
              type="range"
              min="5"
              max="40"
              step="5"
              value={calcHours}
              onChange={(e) => setCalcHours(Number(e.target.value))}
              className="w-full accent-teal-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>5 hrs (Side Gig)</span>
              <span>20 hrs (Part-time)</span>
              <span>40 hrs (Full-time)</span>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
              Skill & Experience Tier
            </label>
            <select
              value={calcTier}
              onChange={(e) => setCalcTier(e.target.value)}
              className="w-full px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="Beginner">Beginner (Fast startup, entry skills)</option>
              <option value="Intermediate">Intermediate (Specialized domain)</option>
              <option value="Advanced">Advanced (High-leverage engineering)</option>
            </select>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-r from-teal-50 to-emerald-50 border border-teal-200/80 text-center md:text-right">
            <span className="text-[11px] font-bold uppercase tracking-wider text-teal-800 block">
              Estimated Monthly Cashflow
            </span>
            <div className="text-2xl sm:text-3xl font-black text-teal-900 font-heading mt-1">
              ${projectedMonthly.toLocaleString()} <span className="text-xs font-semibold text-teal-700">/ month</span>
            </div>
            <span className="text-[10px] text-slate-500">
              Based on verified market rates for {calcTier.toLowerCase()} practitioners
            </span>
          </div>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-teal-600" />
            <h2 className="text-xl font-extrabold text-slate-900 font-heading">
              Curated Earning Roadmaps ({filteredMethods.length})
            </h2>
          </div>

          {/* Skill Filter */}
          <div className="flex items-center gap-2 text-xs font-semibold">
            <span className="text-slate-400">Skill Level:</span>
            {['All', 'Beginner', 'Intermediate', 'Advanced'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setSelectedSkill(lvl)}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  selectedSkill === lvl
                    ? 'bg-teal-600 text-white font-bold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        {/* Category horizontal scroll */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Earning Blueprints */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMethods.map((method) => (
          <div
            key={method.id}
            className="card-3d bg-white rounded-2xl p-6 border border-slate-200 flex flex-col justify-between space-y-5"
          >
            <div className="space-y-3">
              {/* Category & Skill Badge */}
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] uppercase font-extrabold tracking-wider px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-800 border border-teal-200">
                  {method.category}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                  method.skillLevel === 'Beginner'
                    ? 'bg-emerald-100 text-emerald-800'
                    : method.skillLevel === 'Intermediate'
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-purple-100 text-purple-800'
                }`}>
                  {method.skillLevel}
                </span>
              </div>

              {/* Title & Description */}
              <h3 className="text-base sm:text-lg font-extrabold text-slate-900 font-heading line-clamp-2">
                {method.title}
              </h3>

              <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">
                {method.description}
              </p>

              {/* Metrics block */}
              <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Earning Potential</span>
                  <span className="font-extrabold text-emerald-700">{method.earningPotential || method.avgMonthlyEarning}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Time to First $</span>
                  <span className="font-semibold text-slate-700">{method.timeToFirstDollar || method.timeCommitment}</span>
                </div>
              </div>

              {/* Prerequisites */}
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
                  Required Prerequisites
                </span>
                <ul className="space-y-1 text-xs text-slate-600">
                  {method.prerequisites.slice(0, 3).map((req, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span className="line-clamp-1">{req}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Actions & Platform links */}
            <div className="pt-3 border-t border-slate-100 space-y-3">
              <div className="flex flex-wrap gap-1.5">
                {method.recommendedPlatforms.slice(0, 2).map((p, idx) => (
                  <span key={idx} className="text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                    {p.name}
                  </span>
                ))}
              </div>

              <button
                onClick={() => onSelectMethod(method)}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-teal-600 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
              >
                <span>Read Full Step-by-Step Blueprint</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
