import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory subscribers store
interface SubRecord {
  id: string;
  email: string;
  country: string;
  subscribedAt: string;
}
const subscribers: SubRecord[] = [
  { id: 'sub-1', email: 'global.subscriber@mediadb.org', country: 'United States', subscribedAt: '2026-09-01T10:00:00Z' },
  { id: 'sub-2', email: 'uk.media@mediadb.org', country: 'United Kingdom', subscribedAt: '2026-09-02T14:30:00Z' },
  { id: 'sub-3', email: 'cinema.germany@mediadb.org', country: 'Germany', subscribedAt: '2026-09-03T09:15:00Z' },
  { id: 'sub-4', email: 'tokyo.critic@mediadb.org', country: 'Japan', subscribedAt: '2026-09-04T12:00:00Z' },
  { id: 'sub-5', email: 'sydney.watcher@mediadb.org', country: 'Australia', subscribedAt: '2026-09-05T08:45:00Z' },
];

// Lazy Gemini AI Client initialization
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6LMNGMPpwyPhjhCkzxMIjfo1Kcf7pEeuJt4b3a7paqJPQ';
  if (!key) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'MediaDB Backend', timestamp: new Date().toISOString() });
});

// Newsletter Subscription API
app.post('/api/subscribe', (req, res) => {
  const { email, country } = req.body;
  if (!email || typeof email !== 'string' || !email.includes('@')) {
    return res.status(400).json({ error: 'Valid email is required' });
  }

  const existing = subscribers.find(s => s.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.json({ success: true, alreadySubscribed: true, message: 'Already subscribed to MediaDB!' });
  }

  const newSub: SubRecord = {
    id: `sub_${Date.now()}`,
    email: email.trim().toLowerCase(),
    country: country || 'Worldwide',
    subscribedAt: new Date().toISOString(),
  };
  subscribers.unshift(newSub);

  return res.json({
    success: true,
    message: `Subscribed successfully from ${newSub.country}!`,
    count: subscribers.length,
    subscriber: newSub,
  });
});

app.get('/api/subscribers', (req, res) => {
  res.json({
    total: subscribers.length,
    subscribers: subscribers.slice(0, 50),
  });
});

// Gemini AI Real-time Trends Generation Endpoint
app.post('/api/news/generate', async (req, res) => {
  try {
    const { topic, category = 'Entertainment', country = 'Worldwide' } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.status(503).json({ error: 'Gemini AI service unavailable or key missing' });
    }

    const prompt = `Write an SEO-optimized, engaging, journalistic entertainment/tech news story based on the trending topic: "${topic || 'Global Cinema & Box Office Records'}". 
Country context: ${country}. Category: ${category}.
Return ONLY valid JSON with no markdown backticks:
{
  "title": "Journalistic headline under 90 chars",
  "summary": "2-sentence punchy summary explaining the global significance",
  "readTime": "4 min read",
  "content": "Rich 3-paragraph news article detailing behind-the-scenes facts, official announcements, and industry projections.",
  "tags": ["relevant", "keywords", "here"],
  "searchVolume": "50k+",
  "category": "${category}"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = {
        title: topic || 'Global Entertainment Update',
        summary: 'Newly generated breaking entertainment intelligence from MediaDB AI wire.',
        readTime: '3 min read',
        content: text,
        tags: [category, 'MediaDB', 'Trending'],
        category,
      };
    }

    return res.json({
      success: true,
      article: {
        ...data,
        id: `gen-${Date.now()}`,
        slug: (data.title || 'trending-story').toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        country,
        source: 'Google Trends & Gemini AI Wire',
        publishedAt: 'Today',
        verified: true,
      },
    });
  } catch (error: any) {
    console.error('Gemini news generation error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate trend news via Gemini' });
  }
});

// Serve ads-config.js and subscribe.js directly
app.get('/ads-config.js', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'ads-config.js'));
});

app.get('/subscribe.js', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'subscribe.js'));
});

// Setup Vite or Static serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MediaDB Server running on port ${PORT}`);
  });
}

startServer();
