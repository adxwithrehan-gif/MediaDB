#!/usr/bin/env python3
"""
MediaDB - TMDb Automated Data Sync Engine
Syncs Movies, TV Shows, Popular People, and Box Office Trends.
Scheduled Daily at 01:00 AM UTC via GitHub Actions / Cron.
"""

import os
import sys
import json
import time
import urllib.request
import urllib.error
from datetime import datetime

TMDB_API_KEY = os.environ.get("TMDB_API_KEY", "e0454b55527f15c2784604a0bc84df14")
BASE_URL = "https://api.themoviedb.org/3"
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

def fetch_json(url):
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "MediaDB-Bot/2.0"}
        )
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as e:
        print(f"[ERROR] Failed to fetch {url}: {e}", file=sys.stderr)
        return None

def sync_endpoint(category, endpoint, max_pages=3):
    print(f"[*] Syncing TMDb: {category} ({endpoint})...")
    results = []
    for page in range(1, max_pages + 1):
        url = f"{BASE_URL}/{endpoint}?api_key={TMDB_API_KEY}&page={page}"
        data = fetch_json(url)
        if data and "results" in data:
            results.extend(data["results"])
            print(f"    - Page {page}/{max_pages} fetched ({len(data['results'])} items)")
        time.sleep(0.2)  # TMDb rate-limit compliance
    return results

def main():
    print("=" * 60)
    print(f"MediaDB TMDb Sync Bot running at {datetime.utcnow().isoformat()}Z")
    print("=" * 60)

    os.makedirs(DATA_DIR, exist_ok=True)

    endpoints = {
        "movies_popular": "movie/popular",
        "movies_top_rated": "movie/top_rated",
        "movies_now_playing": "movie/now_playing",
        "tv_popular": "tv/popular",
        "tv_top_rated": "tv/top_rated",
        "tv_on_the_air": "tv/on_the_air",
        "people_popular": "person/popular",
        "trending_day": "trending/all/day",
    }

    synced_data = {
        "last_sync": datetime.utcnow().isoformat() + "Z",
        "source": "TheMovieDatabase (TMDb) API v3",
    }

    for key, endpoint in endpoints.items():
        synced_data[key] = sync_endpoint(key, endpoint, max_pages=2)

    output_path = os.path.join(DATA_DIR, "tmdb_latest.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(synced_data, f, indent=2, ensure_ascii=False)

    print(f"[SUCCESS] TMDb sync complete. Saved snapshot to: {output_path}")

if __name__ == "__main__":
    main()
